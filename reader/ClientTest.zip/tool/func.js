const sleep = ms => {
  return new Promise(resolve => setTimeout(resolve, ms))
}


const c = (userService, userRequest) => {
  return new Promise((resolve, reject) => userService.createUser(userRequest, null, (e, r) => {
    console.log('resolve', resolve)
    console.log('reject', reject)

    const obj = {}
    if (e) {
      console.log("error code", e.code);
      console.log("error message", e.message);
      obj.err = e.message
      const err = e.message
      reject(err)
    } else {
      const u = r.getUser().toObject()
      obj.user = u
      console.log("obj1", obj)
      resolve(u)
    }

  }))
}

export { sleep, c }