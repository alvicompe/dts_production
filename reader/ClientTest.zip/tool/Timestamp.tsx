export const timestampHelper = (date: string) => {
  if (window.proto) {
    const proto: any = window.proto;
    const timestamp: any = proto.google.protobuf.Timestamp.fromDate(
      new Date(date)
    );
    return timestamp;
  }
};
