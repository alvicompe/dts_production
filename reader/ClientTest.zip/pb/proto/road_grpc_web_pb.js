/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_point_pb = require('../proto/point_pb.js')
const proto = {};
proto.pb = require('./road_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.RoadServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.RoadServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodDescriptor_RoadService_CreateRoad = new grpc.web.MethodDescriptor(
  '/pb.RoadService/CreateRoad',
  grpc.web.MethodType.UNARY,
  proto.pb.RoadRequest,
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodInfo_RoadService_CreateRoad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.RoadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.RoadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.RoadServiceClient.prototype.createRoad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.RoadService/CreateRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_CreateRoad,
      callback);
};


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.RoadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.RoadServicePromiseClient.prototype.createRoad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.RoadService/CreateRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_CreateRoad);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodDescriptor_RoadService_RetrieveRoad = new grpc.web.MethodDescriptor(
  '/pb.RoadService/RetrieveRoad',
  grpc.web.MethodType.UNARY,
  proto.pb.RoadRequest,
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodInfo_RoadService_RetrieveRoad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.RoadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.RoadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.RoadServiceClient.prototype.retrieveRoad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.RoadService/RetrieveRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_RetrieveRoad,
      callback);
};


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.RoadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.RoadServicePromiseClient.prototype.retrieveRoad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.RoadService/RetrieveRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_RetrieveRoad);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadsResponse>}
 */
const methodDescriptor_RoadService_RetrieveRoads = new grpc.web.MethodDescriptor(
  '/pb.RoadService/RetrieveRoads',
  grpc.web.MethodType.UNARY,
  proto.pb.RoadRequest,
  proto.pb.RoadsResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadsResponse>}
 */
const methodInfo_RoadService_RetrieveRoads = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.RoadsResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.RoadsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.RoadsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.RoadServiceClient.prototype.retrieveRoads =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.RoadService/RetrieveRoads',
      request,
      metadata || {},
      methodDescriptor_RoadService_RetrieveRoads,
      callback);
};


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.RoadsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.RoadServicePromiseClient.prototype.retrieveRoads =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.RoadService/RetrieveRoads',
      request,
      metadata || {},
      methodDescriptor_RoadService_RetrieveRoads);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodDescriptor_RoadService_UpdateRoad = new grpc.web.MethodDescriptor(
  '/pb.RoadService/UpdateRoad',
  grpc.web.MethodType.UNARY,
  proto.pb.RoadRequest,
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodInfo_RoadService_UpdateRoad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.RoadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.RoadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.RoadServiceClient.prototype.updateRoad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.RoadService/UpdateRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_UpdateRoad,
      callback);
};


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.RoadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.RoadServicePromiseClient.prototype.updateRoad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.RoadService/UpdateRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_UpdateRoad);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodDescriptor_RoadService_DeleteRoad = new grpc.web.MethodDescriptor(
  '/pb.RoadService/DeleteRoad',
  grpc.web.MethodType.UNARY,
  proto.pb.RoadRequest,
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.RoadRequest,
 *   !proto.pb.RoadResponse>}
 */
const methodInfo_RoadService_DeleteRoad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.RoadResponse,
  /**
   * @param {!proto.pb.RoadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.RoadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.RoadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.RoadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.RoadServiceClient.prototype.deleteRoad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.RoadService/DeleteRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_DeleteRoad,
      callback);
};


/**
 * @param {!proto.pb.RoadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.RoadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.RoadServicePromiseClient.prototype.deleteRoad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.RoadService/DeleteRoad',
      request,
      metadata || {},
      methodDescriptor_RoadService_DeleteRoad);
};


module.exports = proto.pb;

