/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_point_pb = require('../proto/point_pb.js')

var proto_geofence_pb = require('../proto/geofence_pb.js')

var proto_road_pb = require('../proto/road_pb.js')

var proto_pit_pb = require('../proto/pit_pb.js')

var proto_pad_pb = require('../proto/pad_pb.js')

var proto_stock_pb = require('../proto/stock_pb.js')

var proto_dme_pb = require('../proto/dme_pb.js')
const proto = {};
proto.pb = require('./grid_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.GridServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.GridServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GridRequest,
 *   !proto.pb.GridResponse>}
 */
const methodDescriptor_GridService_CreateGrid = new grpc.web.MethodDescriptor(
  '/pb.GridService/CreateGrid',
  grpc.web.MethodType.UNARY,
  proto.pb.GridRequest,
  proto.pb.GridResponse,
  /**
   * @param {!proto.pb.GridRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GridResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GridRequest,
 *   !proto.pb.GridResponse>}
 */
const methodInfo_GridService_CreateGrid = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GridResponse,
  /**
   * @param {!proto.pb.GridRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GridResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GridRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GridResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GridResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GridServiceClient.prototype.createGrid =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GridService/CreateGrid',
      request,
      metadata || {},
      methodDescriptor_GridService_CreateGrid,
      callback);
};


/**
 * @param {!proto.pb.GridRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GridResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GridServicePromiseClient.prototype.createGrid =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GridService/CreateGrid',
      request,
      metadata || {},
      methodDescriptor_GridService_CreateGrid);
};


module.exports = proto.pb;

