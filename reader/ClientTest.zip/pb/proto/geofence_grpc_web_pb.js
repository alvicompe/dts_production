/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_point_pb = require('../proto/point_pb.js')
const proto = {};
proto.pb = require('./geofence_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.GeofenceServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.GeofenceServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodDescriptor_GeofenceService_CreateGeofence = new grpc.web.MethodDescriptor(
  '/pb.GeofenceService/CreateGeofence',
  grpc.web.MethodType.UNARY,
  proto.pb.GeofenceRequest,
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodInfo_GeofenceService_CreateGeofence = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeofenceResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeofenceResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeofenceServiceClient.prototype.createGeofence =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeofenceService/CreateGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_CreateGeofence,
      callback);
};


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeofenceResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeofenceServicePromiseClient.prototype.createGeofence =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeofenceService/CreateGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_CreateGeofence);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodDescriptor_GeofenceService_RetrieveGeofence = new grpc.web.MethodDescriptor(
  '/pb.GeofenceService/RetrieveGeofence',
  grpc.web.MethodType.UNARY,
  proto.pb.GeofenceRequest,
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodInfo_GeofenceService_RetrieveGeofence = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeofenceResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeofenceResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeofenceServiceClient.prototype.retrieveGeofence =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeofenceService/RetrieveGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_RetrieveGeofence,
      callback);
};


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeofenceResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeofenceServicePromiseClient.prototype.retrieveGeofence =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeofenceService/RetrieveGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_RetrieveGeofence);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofencesResponse>}
 */
const methodDescriptor_GeofenceService_RetrieveGeofences = new grpc.web.MethodDescriptor(
  '/pb.GeofenceService/RetrieveGeofences',
  grpc.web.MethodType.UNARY,
  proto.pb.GeofenceRequest,
  proto.pb.GeofencesResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofencesResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofencesResponse>}
 */
const methodInfo_GeofenceService_RetrieveGeofences = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeofencesResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofencesResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeofencesResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeofencesResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeofenceServiceClient.prototype.retrieveGeofences =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeofenceService/RetrieveGeofences',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_RetrieveGeofences,
      callback);
};


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeofencesResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeofenceServicePromiseClient.prototype.retrieveGeofences =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeofenceService/RetrieveGeofences',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_RetrieveGeofences);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodDescriptor_GeofenceService_UpdateGeofence = new grpc.web.MethodDescriptor(
  '/pb.GeofenceService/UpdateGeofence',
  grpc.web.MethodType.UNARY,
  proto.pb.GeofenceRequest,
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodInfo_GeofenceService_UpdateGeofence = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeofenceResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeofenceResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeofenceServiceClient.prototype.updateGeofence =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeofenceService/UpdateGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_UpdateGeofence,
      callback);
};


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeofenceResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeofenceServicePromiseClient.prototype.updateGeofence =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeofenceService/UpdateGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_UpdateGeofence);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodDescriptor_GeofenceService_DeleteGeofence = new grpc.web.MethodDescriptor(
  '/pb.GeofenceService/DeleteGeofence',
  grpc.web.MethodType.UNARY,
  proto.pb.GeofenceRequest,
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeofenceRequest,
 *   !proto.pb.GeofenceResponse>}
 */
const methodInfo_GeofenceService_DeleteGeofence = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeofenceResponse,
  /**
   * @param {!proto.pb.GeofenceRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeofenceResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeofenceResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeofenceResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeofenceServiceClient.prototype.deleteGeofence =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeofenceService/DeleteGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_DeleteGeofence,
      callback);
};


/**
 * @param {!proto.pb.GeofenceRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeofenceResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeofenceServicePromiseClient.prototype.deleteGeofence =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeofenceService/DeleteGeofence',
      request,
      metadata || {},
      methodDescriptor_GeofenceService_DeleteGeofence);
};


module.exports = proto.pb;

