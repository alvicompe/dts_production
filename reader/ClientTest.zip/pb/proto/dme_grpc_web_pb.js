/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_cell_pb = require('../proto/cell_pb.js')
const proto = {};
proto.pb = require('./dme_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.DmeServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.DmeServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodDescriptor_DmeService_CreateDme = new grpc.web.MethodDescriptor(
  '/pb.DmeService/CreateDme',
  grpc.web.MethodType.UNARY,
  proto.pb.DmeRequest,
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodInfo_DmeService_CreateDme = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.DmeResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.DmeResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.DmeServiceClient.prototype.createDme =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.DmeService/CreateDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_CreateDme,
      callback);
};


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.DmeResponse>}
 *     Promise that resolves to the response
 */
proto.pb.DmeServicePromiseClient.prototype.createDme =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.DmeService/CreateDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_CreateDme);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodDescriptor_DmeService_RetrieveDme = new grpc.web.MethodDescriptor(
  '/pb.DmeService/RetrieveDme',
  grpc.web.MethodType.UNARY,
  proto.pb.DmeRequest,
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodInfo_DmeService_RetrieveDme = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.DmeResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.DmeResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.DmeServiceClient.prototype.retrieveDme =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.DmeService/RetrieveDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_RetrieveDme,
      callback);
};


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.DmeResponse>}
 *     Promise that resolves to the response
 */
proto.pb.DmeServicePromiseClient.prototype.retrieveDme =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.DmeService/RetrieveDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_RetrieveDme);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmesResponse>}
 */
const methodDescriptor_DmeService_RetrieveDmes = new grpc.web.MethodDescriptor(
  '/pb.DmeService/RetrieveDmes',
  grpc.web.MethodType.UNARY,
  proto.pb.DmeRequest,
  proto.pb.DmesResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmesResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmesResponse>}
 */
const methodInfo_DmeService_RetrieveDmes = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.DmesResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmesResponse.deserializeBinary
);


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.DmesResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.DmesResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.DmeServiceClient.prototype.retrieveDmes =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.DmeService/RetrieveDmes',
      request,
      metadata || {},
      methodDescriptor_DmeService_RetrieveDmes,
      callback);
};


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.DmesResponse>}
 *     Promise that resolves to the response
 */
proto.pb.DmeServicePromiseClient.prototype.retrieveDmes =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.DmeService/RetrieveDmes',
      request,
      metadata || {},
      methodDescriptor_DmeService_RetrieveDmes);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodDescriptor_DmeService_UpdateDme = new grpc.web.MethodDescriptor(
  '/pb.DmeService/UpdateDme',
  grpc.web.MethodType.UNARY,
  proto.pb.DmeRequest,
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodInfo_DmeService_UpdateDme = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.DmeResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.DmeResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.DmeServiceClient.prototype.updateDme =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.DmeService/UpdateDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_UpdateDme,
      callback);
};


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.DmeResponse>}
 *     Promise that resolves to the response
 */
proto.pb.DmeServicePromiseClient.prototype.updateDme =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.DmeService/UpdateDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_UpdateDme);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodDescriptor_DmeService_DeleteDme = new grpc.web.MethodDescriptor(
  '/pb.DmeService/DeleteDme',
  grpc.web.MethodType.UNARY,
  proto.pb.DmeRequest,
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.DmeRequest,
 *   !proto.pb.DmeResponse>}
 */
const methodInfo_DmeService_DeleteDme = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.DmeResponse,
  /**
   * @param {!proto.pb.DmeRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DmeResponse.deserializeBinary
);


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.DmeResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.DmeResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.DmeServiceClient.prototype.deleteDme =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.DmeService/DeleteDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_DeleteDme,
      callback);
};


/**
 * @param {!proto.pb.DmeRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.DmeResponse>}
 *     Promise that resolves to the response
 */
proto.pb.DmeServicePromiseClient.prototype.deleteDme =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.DmeService/DeleteDme',
      request,
      metadata || {},
      methodDescriptor_DmeService_DeleteDme);
};


module.exports = proto.pb;

