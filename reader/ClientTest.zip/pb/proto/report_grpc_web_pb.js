/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_cycle_pb = require('../proto/cycle_pb.js')

var proto_truck_pb = require('../proto/truck_pb.js')

var proto_excavator_pb = require('../proto/excavator_pb.js')

var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js')
const proto = {};
proto.pb = require('./report_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ReportServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ReportServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ReportRequest,
 *   !proto.pb.ReportResponse>}
 */
const methodDescriptor_ReportService_RetrieveReport = new grpc.web.MethodDescriptor(
  '/pb.ReportService/RetrieveReport',
  grpc.web.MethodType.UNARY,
  proto.pb.ReportRequest,
  proto.pb.ReportResponse,
  /**
   * @param {!proto.pb.ReportRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ReportResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ReportRequest,
 *   !proto.pb.ReportResponse>}
 */
const methodInfo_ReportService_RetrieveReport = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ReportResponse,
  /**
   * @param {!proto.pb.ReportRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ReportResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ReportRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ReportResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ReportResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ReportServiceClient.prototype.retrieveReport =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ReportService/RetrieveReport',
      request,
      metadata || {},
      methodDescriptor_ReportService_RetrieveReport,
      callback);
};


/**
 * @param {!proto.pb.ReportRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ReportResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ReportServicePromiseClient.prototype.retrieveReport =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ReportService/RetrieveReport',
      request,
      metadata || {},
      methodDescriptor_ReportService_RetrieveReport);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.DownloadRequest,
 *   !proto.pb.DownloadResponse>}
 */
const methodDescriptor_ReportService_DownloadReport = new grpc.web.MethodDescriptor(
  '/pb.ReportService/DownloadReport',
  grpc.web.MethodType.UNARY,
  proto.pb.DownloadRequest,
  proto.pb.DownloadResponse,
  /**
   * @param {!proto.pb.DownloadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DownloadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.DownloadRequest,
 *   !proto.pb.DownloadResponse>}
 */
const methodInfo_ReportService_DownloadReport = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.DownloadResponse,
  /**
   * @param {!proto.pb.DownloadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.DownloadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.DownloadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.DownloadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.DownloadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ReportServiceClient.prototype.downloadReport =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ReportService/DownloadReport',
      request,
      metadata || {},
      methodDescriptor_ReportService_DownloadReport,
      callback);
};


/**
 * @param {!proto.pb.DownloadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.DownloadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ReportServicePromiseClient.prototype.downloadReport =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ReportService/DownloadReport',
      request,
      metadata || {},
      methodDescriptor_ReportService_DownloadReport);
};


module.exports = proto.pb;

