/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_project_pb = require('../proto/project_pb.js')
const proto = {};
proto.pb = require('./pit_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.PitServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.PitServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodDescriptor_PitService_CreatePit = new grpc.web.MethodDescriptor(
  '/pb.PitService/CreatePit',
  grpc.web.MethodType.UNARY,
  proto.pb.PitRequest,
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodInfo_PitService_CreatePit = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PitResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PitResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PitServiceClient.prototype.createPit =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PitService/CreatePit',
      request,
      metadata || {},
      methodDescriptor_PitService_CreatePit,
      callback);
};


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PitResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PitServicePromiseClient.prototype.createPit =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PitService/CreatePit',
      request,
      metadata || {},
      methodDescriptor_PitService_CreatePit);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodDescriptor_PitService_RetrievePit = new grpc.web.MethodDescriptor(
  '/pb.PitService/RetrievePit',
  grpc.web.MethodType.UNARY,
  proto.pb.PitRequest,
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodInfo_PitService_RetrievePit = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PitResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PitResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PitServiceClient.prototype.retrievePit =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PitService/RetrievePit',
      request,
      metadata || {},
      methodDescriptor_PitService_RetrievePit,
      callback);
};


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PitResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PitServicePromiseClient.prototype.retrievePit =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PitService/RetrievePit',
      request,
      metadata || {},
      methodDescriptor_PitService_RetrievePit);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitsResponse>}
 */
const methodDescriptor_PitService_RetrievePits = new grpc.web.MethodDescriptor(
  '/pb.PitService/RetrievePits',
  grpc.web.MethodType.UNARY,
  proto.pb.PitRequest,
  proto.pb.PitsResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitsResponse>}
 */
const methodInfo_PitService_RetrievePits = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PitsResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PitsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PitsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PitServiceClient.prototype.retrievePits =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PitService/RetrievePits',
      request,
      metadata || {},
      methodDescriptor_PitService_RetrievePits,
      callback);
};


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PitsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PitServicePromiseClient.prototype.retrievePits =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PitService/RetrievePits',
      request,
      metadata || {},
      methodDescriptor_PitService_RetrievePits);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodDescriptor_PitService_UpdatePit = new grpc.web.MethodDescriptor(
  '/pb.PitService/UpdatePit',
  grpc.web.MethodType.UNARY,
  proto.pb.PitRequest,
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodInfo_PitService_UpdatePit = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PitResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PitResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PitServiceClient.prototype.updatePit =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PitService/UpdatePit',
      request,
      metadata || {},
      methodDescriptor_PitService_UpdatePit,
      callback);
};


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PitResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PitServicePromiseClient.prototype.updatePit =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PitService/UpdatePit',
      request,
      metadata || {},
      methodDescriptor_PitService_UpdatePit);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodDescriptor_PitService_DeletePit = new grpc.web.MethodDescriptor(
  '/pb.PitService/DeletePit',
  grpc.web.MethodType.UNARY,
  proto.pb.PitRequest,
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PitRequest,
 *   !proto.pb.PitResponse>}
 */
const methodInfo_PitService_DeletePit = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PitResponse,
  /**
   * @param {!proto.pb.PitRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PitResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PitResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PitResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PitServiceClient.prototype.deletePit =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PitService/DeletePit',
      request,
      metadata || {},
      methodDescriptor_PitService_DeletePit,
      callback);
};


/**
 * @param {!proto.pb.PitRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PitResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PitServicePromiseClient.prototype.deletePit =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PitService/DeletePit',
      request,
      metadata || {},
      methodDescriptor_PitService_DeletePit);
};


module.exports = proto.pb;

