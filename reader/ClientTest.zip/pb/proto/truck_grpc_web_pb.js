/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_contractor_pb = require('../proto/contractor_pb.js')
const proto = {};
proto.pb = require('./truck_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.TruckServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.TruckServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodDescriptor_TruckService_CreateTruck = new grpc.web.MethodDescriptor(
  '/pb.TruckService/CreateTruck',
  grpc.web.MethodType.UNARY,
  proto.pb.TruckRequest,
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodInfo_TruckService_CreateTruck = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.TruckResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.TruckResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.TruckServiceClient.prototype.createTruck =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.TruckService/CreateTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_CreateTruck,
      callback);
};


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.TruckResponse>}
 *     Promise that resolves to the response
 */
proto.pb.TruckServicePromiseClient.prototype.createTruck =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.TruckService/CreateTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_CreateTruck);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodDescriptor_TruckService_RetrieveTruck = new grpc.web.MethodDescriptor(
  '/pb.TruckService/RetrieveTruck',
  grpc.web.MethodType.UNARY,
  proto.pb.TruckRequest,
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodInfo_TruckService_RetrieveTruck = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.TruckResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.TruckResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.TruckServiceClient.prototype.retrieveTruck =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.TruckService/RetrieveTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_RetrieveTruck,
      callback);
};


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.TruckResponse>}
 *     Promise that resolves to the response
 */
proto.pb.TruckServicePromiseClient.prototype.retrieveTruck =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.TruckService/RetrieveTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_RetrieveTruck);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TrucksResponse>}
 */
const methodDescriptor_TruckService_RetrieveTrucks = new grpc.web.MethodDescriptor(
  '/pb.TruckService/RetrieveTrucks',
  grpc.web.MethodType.UNARY,
  proto.pb.TruckRequest,
  proto.pb.TrucksResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TrucksResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TrucksResponse>}
 */
const methodInfo_TruckService_RetrieveTrucks = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.TrucksResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TrucksResponse.deserializeBinary
);


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.TrucksResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.TrucksResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.TruckServiceClient.prototype.retrieveTrucks =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.TruckService/RetrieveTrucks',
      request,
      metadata || {},
      methodDescriptor_TruckService_RetrieveTrucks,
      callback);
};


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.TrucksResponse>}
 *     Promise that resolves to the response
 */
proto.pb.TruckServicePromiseClient.prototype.retrieveTrucks =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.TruckService/RetrieveTrucks',
      request,
      metadata || {},
      methodDescriptor_TruckService_RetrieveTrucks);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodDescriptor_TruckService_UpdateTruck = new grpc.web.MethodDescriptor(
  '/pb.TruckService/UpdateTruck',
  grpc.web.MethodType.UNARY,
  proto.pb.TruckRequest,
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodInfo_TruckService_UpdateTruck = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.TruckResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.TruckResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.TruckServiceClient.prototype.updateTruck =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.TruckService/UpdateTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_UpdateTruck,
      callback);
};


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.TruckResponse>}
 *     Promise that resolves to the response
 */
proto.pb.TruckServicePromiseClient.prototype.updateTruck =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.TruckService/UpdateTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_UpdateTruck);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodDescriptor_TruckService_DeleteTruck = new grpc.web.MethodDescriptor(
  '/pb.TruckService/DeleteTruck',
  grpc.web.MethodType.UNARY,
  proto.pb.TruckRequest,
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.TruckRequest,
 *   !proto.pb.TruckResponse>}
 */
const methodInfo_TruckService_DeleteTruck = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.TruckResponse,
  /**
   * @param {!proto.pb.TruckRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckResponse.deserializeBinary
);


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.TruckResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.TruckResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.TruckServiceClient.prototype.deleteTruck =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.TruckService/DeleteTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_DeleteTruck,
      callback);
};


/**
 * @param {!proto.pb.TruckRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.TruckResponse>}
 *     Promise that resolves to the response
 */
proto.pb.TruckServicePromiseClient.prototype.deleteTruck =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.TruckService/DeleteTruck',
      request,
      metadata || {},
      methodDescriptor_TruckService_DeleteTruck);
};


module.exports = proto.pb;

