/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_cell_pb = require('../proto/cell_pb.js')
const proto = {};
proto.pb = require('./pad_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.PadServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.PadServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodDescriptor_PadService_CreatePad = new grpc.web.MethodDescriptor(
  '/pb.PadService/CreatePad',
  grpc.web.MethodType.UNARY,
  proto.pb.PadRequest,
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodInfo_PadService_CreatePad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PadServiceClient.prototype.createPad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PadService/CreatePad',
      request,
      metadata || {},
      methodDescriptor_PadService_CreatePad,
      callback);
};


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PadServicePromiseClient.prototype.createPad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PadService/CreatePad',
      request,
      metadata || {},
      methodDescriptor_PadService_CreatePad);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodDescriptor_PadService_RetrievePad = new grpc.web.MethodDescriptor(
  '/pb.PadService/RetrievePad',
  grpc.web.MethodType.UNARY,
  proto.pb.PadRequest,
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodInfo_PadService_RetrievePad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PadServiceClient.prototype.retrievePad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PadService/RetrievePad',
      request,
      metadata || {},
      methodDescriptor_PadService_RetrievePad,
      callback);
};


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PadServicePromiseClient.prototype.retrievePad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PadService/RetrievePad',
      request,
      metadata || {},
      methodDescriptor_PadService_RetrievePad);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadsResponse>}
 */
const methodDescriptor_PadService_RetrievePads = new grpc.web.MethodDescriptor(
  '/pb.PadService/RetrievePads',
  grpc.web.MethodType.UNARY,
  proto.pb.PadRequest,
  proto.pb.PadsResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadsResponse>}
 */
const methodInfo_PadService_RetrievePads = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PadsResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PadsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PadsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PadServiceClient.prototype.retrievePads =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PadService/RetrievePads',
      request,
      metadata || {},
      methodDescriptor_PadService_RetrievePads,
      callback);
};


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PadsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PadServicePromiseClient.prototype.retrievePads =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PadService/RetrievePads',
      request,
      metadata || {},
      methodDescriptor_PadService_RetrievePads);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodDescriptor_PadService_UpdatePad = new grpc.web.MethodDescriptor(
  '/pb.PadService/UpdatePad',
  grpc.web.MethodType.UNARY,
  proto.pb.PadRequest,
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodInfo_PadService_UpdatePad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PadServiceClient.prototype.updatePad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PadService/UpdatePad',
      request,
      metadata || {},
      methodDescriptor_PadService_UpdatePad,
      callback);
};


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PadServicePromiseClient.prototype.updatePad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PadService/UpdatePad',
      request,
      metadata || {},
      methodDescriptor_PadService_UpdatePad);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodDescriptor_PadService_DeletePad = new grpc.web.MethodDescriptor(
  '/pb.PadService/DeletePad',
  grpc.web.MethodType.UNARY,
  proto.pb.PadRequest,
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PadRequest,
 *   !proto.pb.PadResponse>}
 */
const methodInfo_PadService_DeletePad = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PadResponse,
  /**
   * @param {!proto.pb.PadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PadResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PadServiceClient.prototype.deletePad =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PadService/DeletePad',
      request,
      metadata || {},
      methodDescriptor_PadService_DeletePad,
      callback);
};


/**
 * @param {!proto.pb.PadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PadResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PadServicePromiseClient.prototype.deletePad =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PadService/DeletePad',
      request,
      metadata || {},
      methodDescriptor_PadService_DeletePad);
};


module.exports = proto.pb;

