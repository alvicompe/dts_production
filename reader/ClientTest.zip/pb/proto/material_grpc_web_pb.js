/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.pb = require('./material_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.MaterialServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.MaterialServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodDescriptor_MaterialService_CreateMaterial = new grpc.web.MethodDescriptor(
  '/pb.MaterialService/CreateMaterial',
  grpc.web.MethodType.UNARY,
  proto.pb.MaterialRequest,
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodInfo_MaterialService_CreateMaterial = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.MaterialResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.MaterialResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.MaterialServiceClient.prototype.createMaterial =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.MaterialService/CreateMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_CreateMaterial,
      callback);
};


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.MaterialResponse>}
 *     Promise that resolves to the response
 */
proto.pb.MaterialServicePromiseClient.prototype.createMaterial =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.MaterialService/CreateMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_CreateMaterial);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodDescriptor_MaterialService_RetrieveMaterial = new grpc.web.MethodDescriptor(
  '/pb.MaterialService/RetrieveMaterial',
  grpc.web.MethodType.UNARY,
  proto.pb.MaterialRequest,
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodInfo_MaterialService_RetrieveMaterial = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.MaterialResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.MaterialResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.MaterialServiceClient.prototype.retrieveMaterial =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.MaterialService/RetrieveMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_RetrieveMaterial,
      callback);
};


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.MaterialResponse>}
 *     Promise that resolves to the response
 */
proto.pb.MaterialServicePromiseClient.prototype.retrieveMaterial =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.MaterialService/RetrieveMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_RetrieveMaterial);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialsResponse>}
 */
const methodDescriptor_MaterialService_RetrieveMaterials = new grpc.web.MethodDescriptor(
  '/pb.MaterialService/RetrieveMaterials',
  grpc.web.MethodType.UNARY,
  proto.pb.MaterialRequest,
  proto.pb.MaterialsResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialsResponse>}
 */
const methodInfo_MaterialService_RetrieveMaterials = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.MaterialsResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.MaterialsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.MaterialsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.MaterialServiceClient.prototype.retrieveMaterials =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.MaterialService/RetrieveMaterials',
      request,
      metadata || {},
      methodDescriptor_MaterialService_RetrieveMaterials,
      callback);
};


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.MaterialsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.MaterialServicePromiseClient.prototype.retrieveMaterials =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.MaterialService/RetrieveMaterials',
      request,
      metadata || {},
      methodDescriptor_MaterialService_RetrieveMaterials);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodDescriptor_MaterialService_UpdateMaterial = new grpc.web.MethodDescriptor(
  '/pb.MaterialService/UpdateMaterial',
  grpc.web.MethodType.UNARY,
  proto.pb.MaterialRequest,
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodInfo_MaterialService_UpdateMaterial = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.MaterialResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.MaterialResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.MaterialServiceClient.prototype.updateMaterial =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.MaterialService/UpdateMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_UpdateMaterial,
      callback);
};


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.MaterialResponse>}
 *     Promise that resolves to the response
 */
proto.pb.MaterialServicePromiseClient.prototype.updateMaterial =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.MaterialService/UpdateMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_UpdateMaterial);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodDescriptor_MaterialService_DeleteMaterial = new grpc.web.MethodDescriptor(
  '/pb.MaterialService/DeleteMaterial',
  grpc.web.MethodType.UNARY,
  proto.pb.MaterialRequest,
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.MaterialRequest,
 *   !proto.pb.MaterialResponse>}
 */
const methodInfo_MaterialService_DeleteMaterial = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.MaterialResponse,
  /**
   * @param {!proto.pb.MaterialRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.MaterialResponse.deserializeBinary
);


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.MaterialResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.MaterialResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.MaterialServiceClient.prototype.deleteMaterial =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.MaterialService/DeleteMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_DeleteMaterial,
      callback);
};


/**
 * @param {!proto.pb.MaterialRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.MaterialResponse>}
 *     Promise that resolves to the response
 */
proto.pb.MaterialServicePromiseClient.prototype.deleteMaterial =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.MaterialService/DeleteMaterial',
      request,
      metadata || {},
      methodDescriptor_MaterialService_DeleteMaterial);
};


module.exports = proto.pb;

