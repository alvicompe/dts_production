/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.pb = require('./contractor_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ContractorServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ContractorServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodDescriptor_ContractorService_CreateContractor = new grpc.web.MethodDescriptor(
  '/pb.ContractorService/CreateContractor',
  grpc.web.MethodType.UNARY,
  proto.pb.ContractorRequest,
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodInfo_ContractorService_CreateContractor = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ContractorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ContractorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ContractorServiceClient.prototype.createContractor =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ContractorService/CreateContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_CreateContractor,
      callback);
};


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ContractorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ContractorServicePromiseClient.prototype.createContractor =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ContractorService/CreateContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_CreateContractor);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodDescriptor_ContractorService_RetrieveContractor = new grpc.web.MethodDescriptor(
  '/pb.ContractorService/RetrieveContractor',
  grpc.web.MethodType.UNARY,
  proto.pb.ContractorRequest,
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodInfo_ContractorService_RetrieveContractor = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ContractorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ContractorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ContractorServiceClient.prototype.retrieveContractor =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ContractorService/RetrieveContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_RetrieveContractor,
      callback);
};


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ContractorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ContractorServicePromiseClient.prototype.retrieveContractor =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ContractorService/RetrieveContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_RetrieveContractor);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorsResponse>}
 */
const methodDescriptor_ContractorService_RetrieveContractors = new grpc.web.MethodDescriptor(
  '/pb.ContractorService/RetrieveContractors',
  grpc.web.MethodType.UNARY,
  proto.pb.ContractorRequest,
  proto.pb.ContractorsResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorsResponse>}
 */
const methodInfo_ContractorService_RetrieveContractors = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ContractorsResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ContractorsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ContractorsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ContractorServiceClient.prototype.retrieveContractors =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ContractorService/RetrieveContractors',
      request,
      metadata || {},
      methodDescriptor_ContractorService_RetrieveContractors,
      callback);
};


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ContractorsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ContractorServicePromiseClient.prototype.retrieveContractors =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ContractorService/RetrieveContractors',
      request,
      metadata || {},
      methodDescriptor_ContractorService_RetrieveContractors);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodDescriptor_ContractorService_UpdateContractor = new grpc.web.MethodDescriptor(
  '/pb.ContractorService/UpdateContractor',
  grpc.web.MethodType.UNARY,
  proto.pb.ContractorRequest,
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodInfo_ContractorService_UpdateContractor = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ContractorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ContractorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ContractorServiceClient.prototype.updateContractor =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ContractorService/UpdateContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_UpdateContractor,
      callback);
};


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ContractorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ContractorServicePromiseClient.prototype.updateContractor =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ContractorService/UpdateContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_UpdateContractor);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodDescriptor_ContractorService_DeleteContractor = new grpc.web.MethodDescriptor(
  '/pb.ContractorService/DeleteContractor',
  grpc.web.MethodType.UNARY,
  proto.pb.ContractorRequest,
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ContractorRequest,
 *   !proto.pb.ContractorResponse>}
 */
const methodInfo_ContractorService_DeleteContractor = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ContractorResponse,
  /**
   * @param {!proto.pb.ContractorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ContractorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ContractorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ContractorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ContractorServiceClient.prototype.deleteContractor =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ContractorService/DeleteContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_DeleteContractor,
      callback);
};


/**
 * @param {!proto.pb.ContractorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ContractorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ContractorServicePromiseClient.prototype.deleteContractor =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ContractorService/DeleteContractor',
      request,
      metadata || {},
      methodDescriptor_ContractorService_DeleteContractor);
};


module.exports = proto.pb;

