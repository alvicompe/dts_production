/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_point_pb = require('../proto/point_pb.js')
const proto = {};
proto.pb = require('./cell_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.CellServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.CellServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodDescriptor_CellService_CreateCell = new grpc.web.MethodDescriptor(
  '/pb.CellService/CreateCell',
  grpc.web.MethodType.UNARY,
  proto.pb.CellRequest,
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodInfo_CellService_CreateCell = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CellResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CellResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CellServiceClient.prototype.createCell =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CellService/CreateCell',
      request,
      metadata || {},
      methodDescriptor_CellService_CreateCell,
      callback);
};


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CellResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CellServicePromiseClient.prototype.createCell =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CellService/CreateCell',
      request,
      metadata || {},
      methodDescriptor_CellService_CreateCell);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodDescriptor_CellService_RetrieveCell = new grpc.web.MethodDescriptor(
  '/pb.CellService/RetrieveCell',
  grpc.web.MethodType.UNARY,
  proto.pb.CellRequest,
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodInfo_CellService_RetrieveCell = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CellResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CellResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CellServiceClient.prototype.retrieveCell =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CellService/RetrieveCell',
      request,
      metadata || {},
      methodDescriptor_CellService_RetrieveCell,
      callback);
};


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CellResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CellServicePromiseClient.prototype.retrieveCell =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CellService/RetrieveCell',
      request,
      metadata || {},
      methodDescriptor_CellService_RetrieveCell);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellsResponse>}
 */
const methodDescriptor_CellService_RetrieveCells = new grpc.web.MethodDescriptor(
  '/pb.CellService/RetrieveCells',
  grpc.web.MethodType.UNARY,
  proto.pb.CellRequest,
  proto.pb.CellsResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellsResponse>}
 */
const methodInfo_CellService_RetrieveCells = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CellsResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CellsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CellsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CellServiceClient.prototype.retrieveCells =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CellService/RetrieveCells',
      request,
      metadata || {},
      methodDescriptor_CellService_RetrieveCells,
      callback);
};


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CellsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CellServicePromiseClient.prototype.retrieveCells =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CellService/RetrieveCells',
      request,
      metadata || {},
      methodDescriptor_CellService_RetrieveCells);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodDescriptor_CellService_UpdateCell = new grpc.web.MethodDescriptor(
  '/pb.CellService/UpdateCell',
  grpc.web.MethodType.UNARY,
  proto.pb.CellRequest,
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodInfo_CellService_UpdateCell = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CellResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CellResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CellServiceClient.prototype.updateCell =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CellService/UpdateCell',
      request,
      metadata || {},
      methodDescriptor_CellService_UpdateCell,
      callback);
};


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CellResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CellServicePromiseClient.prototype.updateCell =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CellService/UpdateCell',
      request,
      metadata || {},
      methodDescriptor_CellService_UpdateCell);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodDescriptor_CellService_DeleteCell = new grpc.web.MethodDescriptor(
  '/pb.CellService/DeleteCell',
  grpc.web.MethodType.UNARY,
  proto.pb.CellRequest,
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CellRequest,
 *   !proto.pb.CellResponse>}
 */
const methodInfo_CellService_DeleteCell = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CellResponse,
  /**
   * @param {!proto.pb.CellRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CellResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CellResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CellResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CellServiceClient.prototype.deleteCell =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CellService/DeleteCell',
      request,
      metadata || {},
      methodDescriptor_CellService_DeleteCell,
      callback);
};


/**
 * @param {!proto.pb.CellRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CellResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CellServicePromiseClient.prototype.deleteCell =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CellService/DeleteCell',
      request,
      metadata || {},
      methodDescriptor_CellService_DeleteCell);
};


module.exports = proto.pb;

