/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_geofence_pb = require('../proto/geofence_pb.js')

var proto_road_pb = require('../proto/road_pb.js')

var proto_point_pb = require('../proto/point_pb.js')

var proto_sensor_pb = require('../proto/sensor_pb.js')

var proto_pit_pb = require('../proto/pit_pb.js')

var proto_pad_pb = require('../proto/pad_pb.js')

var proto_stock_pb = require('../proto/stock_pb.js')

var proto_dme_pb = require('../proto/dme_pb.js')

var proto_excavator_pb = require('../proto/excavator_pb.js')

var proto_truck_pb = require('../proto/truck_pb.js')

var proto_load_pb = require('../proto/load_pb.js')
const proto = {};
proto.pb = require('./streaming_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.TruckInfoServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.TruckInfoServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.TruckInfoRequest,
 *   !proto.pb.TruckInfoResponse>}
 */
const methodDescriptor_TruckInfoService_ServerStream = new grpc.web.MethodDescriptor(
  '/pb.TruckInfoService/ServerStream',
  grpc.web.MethodType.SERVER_STREAMING,
  proto.pb.TruckInfoRequest,
  proto.pb.TruckInfoResponse,
  /**
   * @param {!proto.pb.TruckInfoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckInfoResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.TruckInfoRequest,
 *   !proto.pb.TruckInfoResponse>}
 */
const methodInfo_TruckInfoService_ServerStream = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.TruckInfoResponse,
  /**
   * @param {!proto.pb.TruckInfoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.TruckInfoResponse.deserializeBinary
);


/**
 * @param {!proto.pb.TruckInfoRequest} request The request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!grpc.web.ClientReadableStream<!proto.pb.TruckInfoResponse>}
 *     The XHR Node Readable Stream
 */
proto.pb.TruckInfoServiceClient.prototype.serverStream =
    function(request, metadata) {
  return this.client_.serverStreaming(this.hostname_ +
      '/pb.TruckInfoService/ServerStream',
      request,
      metadata || {},
      methodDescriptor_TruckInfoService_ServerStream);
};


/**
 * @param {!proto.pb.TruckInfoRequest} request The request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!grpc.web.ClientReadableStream<!proto.pb.TruckInfoResponse>}
 *     The XHR Node Readable Stream
 */
proto.pb.TruckInfoServicePromiseClient.prototype.serverStream =
    function(request, metadata) {
  return this.client_.serverStreaming(this.hostname_ +
      '/pb.TruckInfoService/ServerStream',
      request,
      metadata || {},
      methodDescriptor_TruckInfoService_ServerStream);
};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ExcavatorInfoServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ExcavatorInfoServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ExcavatorInfoRequest,
 *   !proto.pb.ExcavatorInfoResponse>}
 */
const methodDescriptor_ExcavatorInfoService_ServerStream = new grpc.web.MethodDescriptor(
  '/pb.ExcavatorInfoService/ServerStream',
  grpc.web.MethodType.SERVER_STREAMING,
  proto.pb.ExcavatorInfoRequest,
  proto.pb.ExcavatorInfoResponse,
  /**
   * @param {!proto.pb.ExcavatorInfoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorInfoResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ExcavatorInfoRequest,
 *   !proto.pb.ExcavatorInfoResponse>}
 */
const methodInfo_ExcavatorInfoService_ServerStream = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ExcavatorInfoResponse,
  /**
   * @param {!proto.pb.ExcavatorInfoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorInfoResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ExcavatorInfoRequest} request The request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ExcavatorInfoResponse>}
 *     The XHR Node Readable Stream
 */
proto.pb.ExcavatorInfoServiceClient.prototype.serverStream =
    function(request, metadata) {
  return this.client_.serverStreaming(this.hostname_ +
      '/pb.ExcavatorInfoService/ServerStream',
      request,
      metadata || {},
      methodDescriptor_ExcavatorInfoService_ServerStream);
};


/**
 * @param {!proto.pb.ExcavatorInfoRequest} request The request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ExcavatorInfoResponse>}
 *     The XHR Node Readable Stream
 */
proto.pb.ExcavatorInfoServicePromiseClient.prototype.serverStream =
    function(request, metadata) {
  return this.client_.serverStreaming(this.hostname_ +
      '/pb.ExcavatorInfoService/ServerStream',
      request,
      metadata || {},
      methodDescriptor_ExcavatorInfoService_ServerStream);
};


module.exports = proto.pb;

