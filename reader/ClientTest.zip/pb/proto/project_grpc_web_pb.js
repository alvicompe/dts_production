/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_polygon_pb = require('../proto/polygon_pb.js')
const proto = {};
proto.pb = require('./project_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ProjectServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ProjectServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodDescriptor_ProjectService_CreateProject = new grpc.web.MethodDescriptor(
  '/pb.ProjectService/CreateProject',
  grpc.web.MethodType.UNARY,
  proto.pb.ProjectRequest,
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodInfo_ProjectService_CreateProject = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ProjectResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ProjectResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ProjectServiceClient.prototype.createProject =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ProjectService/CreateProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_CreateProject,
      callback);
};


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ProjectResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ProjectServicePromiseClient.prototype.createProject =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ProjectService/CreateProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_CreateProject);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodDescriptor_ProjectService_RetrieveProject = new grpc.web.MethodDescriptor(
  '/pb.ProjectService/RetrieveProject',
  grpc.web.MethodType.UNARY,
  proto.pb.ProjectRequest,
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodInfo_ProjectService_RetrieveProject = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ProjectResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ProjectResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ProjectServiceClient.prototype.retrieveProject =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ProjectService/RetrieveProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_RetrieveProject,
      callback);
};


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ProjectResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ProjectServicePromiseClient.prototype.retrieveProject =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ProjectService/RetrieveProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_RetrieveProject);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectsResponse>}
 */
const methodDescriptor_ProjectService_RetrieveProjects = new grpc.web.MethodDescriptor(
  '/pb.ProjectService/RetrieveProjects',
  grpc.web.MethodType.UNARY,
  proto.pb.ProjectRequest,
  proto.pb.ProjectsResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectsResponse>}
 */
const methodInfo_ProjectService_RetrieveProjects = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ProjectsResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ProjectsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ProjectsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ProjectServiceClient.prototype.retrieveProjects =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ProjectService/RetrieveProjects',
      request,
      metadata || {},
      methodDescriptor_ProjectService_RetrieveProjects,
      callback);
};


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ProjectsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ProjectServicePromiseClient.prototype.retrieveProjects =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ProjectService/RetrieveProjects',
      request,
      metadata || {},
      methodDescriptor_ProjectService_RetrieveProjects);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodDescriptor_ProjectService_UpdateProject = new grpc.web.MethodDescriptor(
  '/pb.ProjectService/UpdateProject',
  grpc.web.MethodType.UNARY,
  proto.pb.ProjectRequest,
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodInfo_ProjectService_UpdateProject = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ProjectResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ProjectResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ProjectServiceClient.prototype.updateProject =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ProjectService/UpdateProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_UpdateProject,
      callback);
};


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ProjectResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ProjectServicePromiseClient.prototype.updateProject =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ProjectService/UpdateProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_UpdateProject);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodDescriptor_ProjectService_DeleteProject = new grpc.web.MethodDescriptor(
  '/pb.ProjectService/DeleteProject',
  grpc.web.MethodType.UNARY,
  proto.pb.ProjectRequest,
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ProjectRequest,
 *   !proto.pb.ProjectResponse>}
 */
const methodInfo_ProjectService_DeleteProject = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ProjectResponse,
  /**
   * @param {!proto.pb.ProjectRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ProjectResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ProjectResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ProjectResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ProjectServiceClient.prototype.deleteProject =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ProjectService/DeleteProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_DeleteProject,
      callback);
};


/**
 * @param {!proto.pb.ProjectRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ProjectResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ProjectServicePromiseClient.prototype.deleteProject =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ProjectService/DeleteProject',
      request,
      metadata || {},
      methodDescriptor_ProjectService_DeleteProject);
};


module.exports = proto.pb;

