/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_point_pb = require('../proto/point_pb.js')

var proto_material_pb = require('../proto/material_pb.js')
const proto = {};
proto.pb = require('./polygon_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.PolygonServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.PolygonServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodDescriptor_PolygonService_CreatePolygon = new grpc.web.MethodDescriptor(
  '/pb.PolygonService/CreatePolygon',
  grpc.web.MethodType.UNARY,
  proto.pb.PolygonRequest,
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodInfo_PolygonService_CreatePolygon = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PolygonResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PolygonResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PolygonServiceClient.prototype.createPolygon =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PolygonService/CreatePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_CreatePolygon,
      callback);
};


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PolygonResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PolygonServicePromiseClient.prototype.createPolygon =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PolygonService/CreatePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_CreatePolygon);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodDescriptor_PolygonService_RetrievePolygon = new grpc.web.MethodDescriptor(
  '/pb.PolygonService/RetrievePolygon',
  grpc.web.MethodType.UNARY,
  proto.pb.PolygonRequest,
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodInfo_PolygonService_RetrievePolygon = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PolygonResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PolygonResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PolygonServiceClient.prototype.retrievePolygon =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PolygonService/RetrievePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_RetrievePolygon,
      callback);
};


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PolygonResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PolygonServicePromiseClient.prototype.retrievePolygon =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PolygonService/RetrievePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_RetrievePolygon);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonsResponse>}
 */
const methodDescriptor_PolygonService_RetrievePolygons = new grpc.web.MethodDescriptor(
  '/pb.PolygonService/RetrievePolygons',
  grpc.web.MethodType.UNARY,
  proto.pb.PolygonRequest,
  proto.pb.PolygonsResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonsResponse>}
 */
const methodInfo_PolygonService_RetrievePolygons = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PolygonsResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PolygonsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PolygonsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PolygonServiceClient.prototype.retrievePolygons =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PolygonService/RetrievePolygons',
      request,
      metadata || {},
      methodDescriptor_PolygonService_RetrievePolygons,
      callback);
};


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PolygonsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PolygonServicePromiseClient.prototype.retrievePolygons =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PolygonService/RetrievePolygons',
      request,
      metadata || {},
      methodDescriptor_PolygonService_RetrievePolygons);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodDescriptor_PolygonService_UpdatePolygon = new grpc.web.MethodDescriptor(
  '/pb.PolygonService/UpdatePolygon',
  grpc.web.MethodType.UNARY,
  proto.pb.PolygonRequest,
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodInfo_PolygonService_UpdatePolygon = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PolygonResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PolygonResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PolygonServiceClient.prototype.updatePolygon =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PolygonService/UpdatePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_UpdatePolygon,
      callback);
};


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PolygonResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PolygonServicePromiseClient.prototype.updatePolygon =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PolygonService/UpdatePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_UpdatePolygon);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodDescriptor_PolygonService_DeletePolygon = new grpc.web.MethodDescriptor(
  '/pb.PolygonService/DeletePolygon',
  grpc.web.MethodType.UNARY,
  proto.pb.PolygonRequest,
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.PolygonRequest,
 *   !proto.pb.PolygonResponse>}
 */
const methodInfo_PolygonService_DeletePolygon = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.PolygonResponse,
  /**
   * @param {!proto.pb.PolygonRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.PolygonResponse.deserializeBinary
);


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.PolygonResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.PolygonResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.PolygonServiceClient.prototype.deletePolygon =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.PolygonService/DeletePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_DeletePolygon,
      callback);
};


/**
 * @param {!proto.pb.PolygonRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.PolygonResponse>}
 *     Promise that resolves to the response
 */
proto.pb.PolygonServicePromiseClient.prototype.deletePolygon =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.PolygonService/DeletePolygon',
      request,
      metadata || {},
      methodDescriptor_PolygonService_DeletePolygon);
};


module.exports = proto.pb;

