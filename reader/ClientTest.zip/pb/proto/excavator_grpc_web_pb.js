/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_contractor_pb = require('../proto/contractor_pb.js')
const proto = {};
proto.pb = require('./excavator_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ExcavatorServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.ExcavatorServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodDescriptor_ExcavatorService_CreateExcavator = new grpc.web.MethodDescriptor(
  '/pb.ExcavatorService/CreateExcavator',
  grpc.web.MethodType.UNARY,
  proto.pb.ExcavatorRequest,
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodInfo_ExcavatorService_CreateExcavator = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ExcavatorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ExcavatorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ExcavatorServiceClient.prototype.createExcavator =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ExcavatorService/CreateExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_CreateExcavator,
      callback);
};


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ExcavatorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ExcavatorServicePromiseClient.prototype.createExcavator =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ExcavatorService/CreateExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_CreateExcavator);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodDescriptor_ExcavatorService_RetrieveExcavator = new grpc.web.MethodDescriptor(
  '/pb.ExcavatorService/RetrieveExcavator',
  grpc.web.MethodType.UNARY,
  proto.pb.ExcavatorRequest,
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodInfo_ExcavatorService_RetrieveExcavator = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ExcavatorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ExcavatorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ExcavatorServiceClient.prototype.retrieveExcavator =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ExcavatorService/RetrieveExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_RetrieveExcavator,
      callback);
};


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ExcavatorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ExcavatorServicePromiseClient.prototype.retrieveExcavator =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ExcavatorService/RetrieveExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_RetrieveExcavator);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorsResponse>}
 */
const methodDescriptor_ExcavatorService_RetrieveExcavators = new grpc.web.MethodDescriptor(
  '/pb.ExcavatorService/RetrieveExcavators',
  grpc.web.MethodType.UNARY,
  proto.pb.ExcavatorRequest,
  proto.pb.ExcavatorsResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorsResponse>}
 */
const methodInfo_ExcavatorService_RetrieveExcavators = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ExcavatorsResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ExcavatorsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ExcavatorsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ExcavatorServiceClient.prototype.retrieveExcavators =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ExcavatorService/RetrieveExcavators',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_RetrieveExcavators,
      callback);
};


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ExcavatorsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ExcavatorServicePromiseClient.prototype.retrieveExcavators =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ExcavatorService/RetrieveExcavators',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_RetrieveExcavators);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodDescriptor_ExcavatorService_UpdateExcavator = new grpc.web.MethodDescriptor(
  '/pb.ExcavatorService/UpdateExcavator',
  grpc.web.MethodType.UNARY,
  proto.pb.ExcavatorRequest,
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodInfo_ExcavatorService_UpdateExcavator = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ExcavatorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ExcavatorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ExcavatorServiceClient.prototype.updateExcavator =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ExcavatorService/UpdateExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_UpdateExcavator,
      callback);
};


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ExcavatorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ExcavatorServicePromiseClient.prototype.updateExcavator =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ExcavatorService/UpdateExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_UpdateExcavator);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodDescriptor_ExcavatorService_DeleteExcavator = new grpc.web.MethodDescriptor(
  '/pb.ExcavatorService/DeleteExcavator',
  grpc.web.MethodType.UNARY,
  proto.pb.ExcavatorRequest,
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ExcavatorRequest,
 *   !proto.pb.ExcavatorResponse>}
 */
const methodInfo_ExcavatorService_DeleteExcavator = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ExcavatorResponse,
  /**
   * @param {!proto.pb.ExcavatorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ExcavatorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.ExcavatorResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ExcavatorResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.ExcavatorServiceClient.prototype.deleteExcavator =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.ExcavatorService/DeleteExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_DeleteExcavator,
      callback);
};


/**
 * @param {!proto.pb.ExcavatorRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.ExcavatorResponse>}
 *     Promise that resolves to the response
 */
proto.pb.ExcavatorServicePromiseClient.prototype.deleteExcavator =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.ExcavatorService/DeleteExcavator',
      request,
      metadata || {},
      methodDescriptor_ExcavatorService_DeleteExcavator);
};


module.exports = proto.pb;

