/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_truck_pb = require('../proto/truck_pb.js')

var proto_excavator_pb = require('../proto/excavator_pb.js')

var proto_material_pb = require('../proto/material_pb.js')

var proto_streaming_pb = require('../proto/streaming_pb.js')

var proto_load_pb = require('../proto/load_pb.js')

var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js')
const proto = {};
proto.pb = require('./cycle_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.CycleServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.CycleServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodDescriptor_CycleService_CreateCycle = new grpc.web.MethodDescriptor(
  '/pb.CycleService/CreateCycle',
  grpc.web.MethodType.UNARY,
  proto.pb.CycleRequest,
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodInfo_CycleService_CreateCycle = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CycleResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CycleResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CycleServiceClient.prototype.createCycle =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CycleService/CreateCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_CreateCycle,
      callback);
};


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CycleResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CycleServicePromiseClient.prototype.createCycle =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CycleService/CreateCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_CreateCycle);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodDescriptor_CycleService_RetrieveCycle = new grpc.web.MethodDescriptor(
  '/pb.CycleService/RetrieveCycle',
  grpc.web.MethodType.UNARY,
  proto.pb.CycleRequest,
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodInfo_CycleService_RetrieveCycle = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CycleResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CycleResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CycleServiceClient.prototype.retrieveCycle =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CycleService/RetrieveCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_RetrieveCycle,
      callback);
};


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CycleResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CycleServicePromiseClient.prototype.retrieveCycle =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CycleService/RetrieveCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_RetrieveCycle);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CyclesResponse>}
 */
const methodDescriptor_CycleService_RetrieveCycles = new grpc.web.MethodDescriptor(
  '/pb.CycleService/RetrieveCycles',
  grpc.web.MethodType.UNARY,
  proto.pb.CycleRequest,
  proto.pb.CyclesResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CyclesResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CyclesResponse>}
 */
const methodInfo_CycleService_RetrieveCycles = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CyclesResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CyclesResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CyclesResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CyclesResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CycleServiceClient.prototype.retrieveCycles =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CycleService/RetrieveCycles',
      request,
      metadata || {},
      methodDescriptor_CycleService_RetrieveCycles,
      callback);
};


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CyclesResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CycleServicePromiseClient.prototype.retrieveCycles =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CycleService/RetrieveCycles',
      request,
      metadata || {},
      methodDescriptor_CycleService_RetrieveCycles);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodDescriptor_CycleService_UpdateCycle = new grpc.web.MethodDescriptor(
  '/pb.CycleService/UpdateCycle',
  grpc.web.MethodType.UNARY,
  proto.pb.CycleRequest,
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodInfo_CycleService_UpdateCycle = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CycleResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CycleResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CycleServiceClient.prototype.updateCycle =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CycleService/UpdateCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_UpdateCycle,
      callback);
};


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CycleResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CycleServicePromiseClient.prototype.updateCycle =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CycleService/UpdateCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_UpdateCycle);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodDescriptor_CycleService_DeleteCycle = new grpc.web.MethodDescriptor(
  '/pb.CycleService/DeleteCycle',
  grpc.web.MethodType.UNARY,
  proto.pb.CycleRequest,
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.CycleRequest,
 *   !proto.pb.CycleResponse>}
 */
const methodInfo_CycleService_DeleteCycle = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.CycleResponse,
  /**
   * @param {!proto.pb.CycleRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.CycleResponse.deserializeBinary
);


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.CycleResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.CycleResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.CycleServiceClient.prototype.deleteCycle =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.CycleService/DeleteCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_DeleteCycle,
      callback);
};


/**
 * @param {!proto.pb.CycleRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.CycleResponse>}
 *     Promise that resolves to the response
 */
proto.pb.CycleServicePromiseClient.prototype.deleteCycle =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.CycleService/DeleteCycle',
      request,
      metadata || {},
      methodDescriptor_CycleService_DeleteCycle);
};


module.exports = proto.pb;

