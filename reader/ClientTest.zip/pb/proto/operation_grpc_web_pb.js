/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_truck_pb = require('../proto/truck_pb.js')

var proto_excavator_pb = require('../proto/excavator_pb.js')

var proto_road_pb = require('../proto/road_pb.js')

var proto_cycle_pb = require('../proto/cycle_pb.js')

var proto_load_pb = require('../proto/load_pb.js')

var google_protobuf_timestamp_pb = require('google-protobuf/google/protobuf/timestamp_pb.js')
const proto = {};
proto.pb = require('./operation_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.OperationServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.OperationServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodDescriptor_OperationService_CreateOperation = new grpc.web.MethodDescriptor(
  '/pb.OperationService/CreateOperation',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationRequest,
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodInfo_OperationService_CreateOperation = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.createOperation =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/CreateOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_CreateOperation,
      callback);
};


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.createOperation =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/CreateOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_CreateOperation);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodDescriptor_OperationService_RetrieveOperation = new grpc.web.MethodDescriptor(
  '/pb.OperationService/RetrieveOperation',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationRequest,
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodInfo_OperationService_RetrieveOperation = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.retrieveOperation =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/RetrieveOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_RetrieveOperation,
      callback);
};


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.retrieveOperation =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/RetrieveOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_RetrieveOperation);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationsResponse>}
 */
const methodDescriptor_OperationService_RetrieveOperations = new grpc.web.MethodDescriptor(
  '/pb.OperationService/RetrieveOperations',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationRequest,
  proto.pb.OperationsResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationsResponse>}
 */
const methodInfo_OperationService_RetrieveOperations = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationsResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationsResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.retrieveOperations =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/RetrieveOperations',
      request,
      metadata || {},
      methodDescriptor_OperationService_RetrieveOperations,
      callback);
};


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationsResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.retrieveOperations =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/RetrieveOperations',
      request,
      metadata || {},
      methodDescriptor_OperationService_RetrieveOperations);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodDescriptor_OperationService_UpdateOperation = new grpc.web.MethodDescriptor(
  '/pb.OperationService/UpdateOperation',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationRequest,
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodInfo_OperationService_UpdateOperation = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.updateOperation =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/UpdateOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_UpdateOperation,
      callback);
};


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.updateOperation =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/UpdateOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_UpdateOperation);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodDescriptor_OperationService_DeleteOperation = new grpc.web.MethodDescriptor(
  '/pb.OperationService/DeleteOperation',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationRequest,
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodInfo_OperationService_DeleteOperation = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.deleteOperation =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/DeleteOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_DeleteOperation,
      callback);
};


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.deleteOperation =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/DeleteOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_DeleteOperation);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodDescriptor_OperationService_RemoveTrucksOperation = new grpc.web.MethodDescriptor(
  '/pb.OperationService/RemoveTrucksOperation',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationRequest,
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationResponse>}
 */
const methodInfo_OperationService_RemoveTrucksOperation = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.removeTrucksOperation =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/RemoveTrucksOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_RemoveTrucksOperation,
      callback);
};


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.removeTrucksOperation =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/RemoveTrucksOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_RemoveTrucksOperation);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationReassigmentRequest,
 *   !proto.pb.OperationReassigmentResponse>}
 */
const methodDescriptor_OperationService_ReassigmentTrucksOperation = new grpc.web.MethodDescriptor(
  '/pb.OperationService/ReassigmentTrucksOperation',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationReassigmentRequest,
  proto.pb.OperationReassigmentResponse,
  /**
   * @param {!proto.pb.OperationReassigmentRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationReassigmentResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationReassigmentRequest,
 *   !proto.pb.OperationReassigmentResponse>}
 */
const methodInfo_OperationService_ReassigmentTrucksOperation = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationReassigmentResponse,
  /**
   * @param {!proto.pb.OperationReassigmentRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationReassigmentResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationReassigmentRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationReassigmentResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationReassigmentResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.reassigmentTrucksOperation =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/ReassigmentTrucksOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_ReassigmentTrucksOperation,
      callback);
};


/**
 * @param {!proto.pb.OperationReassigmentRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationReassigmentResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.reassigmentTrucksOperation =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/ReassigmentTrucksOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_ReassigmentTrucksOperation);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationFinalizeResponse>}
 */
const methodDescriptor_OperationService_FinalizeOperation = new grpc.web.MethodDescriptor(
  '/pb.OperationService/FinalizeOperation',
  grpc.web.MethodType.UNARY,
  proto.pb.OperationRequest,
  proto.pb.OperationFinalizeResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationFinalizeResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.OperationRequest,
 *   !proto.pb.OperationFinalizeResponse>}
 */
const methodInfo_OperationService_FinalizeOperation = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.OperationFinalizeResponse,
  /**
   * @param {!proto.pb.OperationRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.OperationFinalizeResponse.deserializeBinary
);


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.OperationFinalizeResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.OperationFinalizeResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.OperationServiceClient.prototype.finalizeOperation =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.OperationService/FinalizeOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_FinalizeOperation,
      callback);
};


/**
 * @param {!proto.pb.OperationRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.OperationFinalizeResponse>}
 *     Promise that resolves to the response
 */
proto.pb.OperationServicePromiseClient.prototype.finalizeOperation =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.OperationService/FinalizeOperation',
      request,
      metadata || {},
      methodDescriptor_OperationService_FinalizeOperation);
};


module.exports = proto.pb;

