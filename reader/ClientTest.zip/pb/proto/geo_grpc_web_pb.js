/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_material_pb = require('../proto/material_pb.js')

var proto_geofence_pb = require('../proto/geofence_pb.js')

var proto_road_pb = require('../proto/road_pb.js')

var proto_pit_pb = require('../proto/pit_pb.js')

var proto_pad_pb = require('../proto/pad_pb.js')

var proto_dme_pb = require('../proto/dme_pb.js')

var proto_stock_pb = require('../proto/stock_pb.js')
const proto = {};
proto.pb = require('./geo_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.GeoServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.GeoServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeoChunkRequest,
 *   !proto.pb.GeoChunkResponse>}
 */
const methodDescriptor_GeoService_UploadGeo = new grpc.web.MethodDescriptor(
  '/pb.GeoService/UploadGeo',
  grpc.web.MethodType.UNARY,
  proto.pb.GeoChunkRequest,
  proto.pb.GeoChunkResponse,
  /**
   * @param {!proto.pb.GeoChunkRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoChunkResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeoChunkRequest,
 *   !proto.pb.GeoChunkResponse>}
 */
const methodInfo_GeoService_UploadGeo = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeoChunkResponse,
  /**
   * @param {!proto.pb.GeoChunkRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoChunkResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeoChunkRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeoChunkResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeoChunkResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeoServiceClient.prototype.uploadGeo =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeoService/UploadGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_UploadGeo,
      callback);
};


/**
 * @param {!proto.pb.GeoChunkRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeoChunkResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeoServicePromiseClient.prototype.uploadGeo =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeoService/UploadGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_UploadGeo);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodDescriptor_GeoService_CreateGeo = new grpc.web.MethodDescriptor(
  '/pb.GeoService/CreateGeo',
  grpc.web.MethodType.UNARY,
  proto.pb.GeoRequest,
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodInfo_GeoService_CreateGeo = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeoResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeoResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeoServiceClient.prototype.createGeo =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeoService/CreateGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_CreateGeo,
      callback);
};


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeoResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeoServicePromiseClient.prototype.createGeo =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeoService/CreateGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_CreateGeo);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodDescriptor_GeoService_RetrieveGeo = new grpc.web.MethodDescriptor(
  '/pb.GeoService/RetrieveGeo',
  grpc.web.MethodType.UNARY,
  proto.pb.GeoRequest,
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodInfo_GeoService_RetrieveGeo = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeoResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeoResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeoServiceClient.prototype.retrieveGeo =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeoService/RetrieveGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_RetrieveGeo,
      callback);
};


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeoResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeoServicePromiseClient.prototype.retrieveGeo =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeoService/RetrieveGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_RetrieveGeo);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeosResponse>}
 */
const methodDescriptor_GeoService_RetrieveGeos = new grpc.web.MethodDescriptor(
  '/pb.GeoService/RetrieveGeos',
  grpc.web.MethodType.UNARY,
  proto.pb.GeoRequest,
  proto.pb.GeosResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeosResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeosResponse>}
 */
const methodInfo_GeoService_RetrieveGeos = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeosResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeosResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeosResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeosResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeoServiceClient.prototype.retrieveGeos =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeoService/RetrieveGeos',
      request,
      metadata || {},
      methodDescriptor_GeoService_RetrieveGeos,
      callback);
};


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeosResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeoServicePromiseClient.prototype.retrieveGeos =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeoService/RetrieveGeos',
      request,
      metadata || {},
      methodDescriptor_GeoService_RetrieveGeos);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodDescriptor_GeoService_UpdateGeo = new grpc.web.MethodDescriptor(
  '/pb.GeoService/UpdateGeo',
  grpc.web.MethodType.UNARY,
  proto.pb.GeoRequest,
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodInfo_GeoService_UpdateGeo = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeoResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeoResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeoServiceClient.prototype.updateGeo =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeoService/UpdateGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_UpdateGeo,
      callback);
};


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeoResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeoServicePromiseClient.prototype.updateGeo =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeoService/UpdateGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_UpdateGeo);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodDescriptor_GeoService_DeleteGeo = new grpc.web.MethodDescriptor(
  '/pb.GeoService/DeleteGeo',
  grpc.web.MethodType.UNARY,
  proto.pb.GeoRequest,
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.GeoRequest,
 *   !proto.pb.GeoResponse>}
 */
const methodInfo_GeoService_DeleteGeo = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.GeoResponse,
  /**
   * @param {!proto.pb.GeoRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.GeoResponse.deserializeBinary
);


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.GeoResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.GeoResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.GeoServiceClient.prototype.deleteGeo =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.GeoService/DeleteGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_DeleteGeo,
      callback);
};


/**
 * @param {!proto.pb.GeoRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.GeoResponse>}
 *     Promise that resolves to the response
 */
proto.pb.GeoServicePromiseClient.prototype.deleteGeo =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.GeoService/DeleteGeo',
      request,
      metadata || {},
      methodDescriptor_GeoService_DeleteGeo);
};


module.exports = proto.pb;

