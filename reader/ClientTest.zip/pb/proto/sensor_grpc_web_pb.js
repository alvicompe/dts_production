/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.pb = require('./sensor_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.SensorServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.SensorServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.ServerSensorRequest,
 *   !proto.pb.ServerSensorResponse>}
 */
const methodDescriptor_SensorService_ServerStream = new grpc.web.MethodDescriptor(
  '/pb.SensorService/ServerStream',
  grpc.web.MethodType.SERVER_STREAMING,
  proto.pb.ServerSensorRequest,
  proto.pb.ServerSensorResponse,
  /**
   * @param {!proto.pb.ServerSensorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ServerSensorResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.ServerSensorRequest,
 *   !proto.pb.ServerSensorResponse>}
 */
const methodInfo_SensorService_ServerStream = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.ServerSensorResponse,
  /**
   * @param {!proto.pb.ServerSensorRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.ServerSensorResponse.deserializeBinary
);


/**
 * @param {!proto.pb.ServerSensorRequest} request The request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ServerSensorResponse>}
 *     The XHR Node Readable Stream
 */
proto.pb.SensorServiceClient.prototype.serverStream =
    function(request, metadata) {
  return this.client_.serverStreaming(this.hostname_ +
      '/pb.SensorService/ServerStream',
      request,
      metadata || {},
      methodDescriptor_SensorService_ServerStream);
};


/**
 * @param {!proto.pb.ServerSensorRequest} request The request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!grpc.web.ClientReadableStream<!proto.pb.ServerSensorResponse>}
 *     The XHR Node Readable Stream
 */
proto.pb.SensorServicePromiseClient.prototype.serverStream =
    function(request, metadata) {
  return this.client_.serverStreaming(this.hostname_ +
      '/pb.SensorService/ServerStream',
      request,
      metadata || {},
      methodDescriptor_SensorService_ServerStream);
};


module.exports = proto.pb;

