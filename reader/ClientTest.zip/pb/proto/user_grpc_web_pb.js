/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.pb = require('./user_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.UserServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.UserServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodDescriptor_UserService_CreateUser = new grpc.web.MethodDescriptor(
  '/pb.UserService/CreateUser',
  grpc.web.MethodType.UNARY,
  proto.pb.UserRequest,
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodInfo_UserService_CreateUser = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.UserResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.UserResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.UserServiceClient.prototype.createUser =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.UserService/CreateUser',
      request,
      metadata || {},
      methodDescriptor_UserService_CreateUser,
      callback);
};


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.UserResponse>}
 *     Promise that resolves to the response
 */
proto.pb.UserServicePromiseClient.prototype.createUser =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.UserService/CreateUser',
      request,
      metadata || {},
      methodDescriptor_UserService_CreateUser);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodDescriptor_UserService_RetrieveUser = new grpc.web.MethodDescriptor(
  '/pb.UserService/RetrieveUser',
  grpc.web.MethodType.UNARY,
  proto.pb.UserRequest,
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodInfo_UserService_RetrieveUser = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.UserResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.UserResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.UserServiceClient.prototype.retrieveUser =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.UserService/RetrieveUser',
      request,
      metadata || {},
      methodDescriptor_UserService_RetrieveUser,
      callback);
};


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.UserResponse>}
 *     Promise that resolves to the response
 */
proto.pb.UserServicePromiseClient.prototype.retrieveUser =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.UserService/RetrieveUser',
      request,
      metadata || {},
      methodDescriptor_UserService_RetrieveUser);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UsersResponse>}
 */
const methodDescriptor_UserService_RetrieveUsers = new grpc.web.MethodDescriptor(
  '/pb.UserService/RetrieveUsers',
  grpc.web.MethodType.UNARY,
  proto.pb.UserRequest,
  proto.pb.UsersResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UsersResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UsersResponse>}
 */
const methodInfo_UserService_RetrieveUsers = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.UsersResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UsersResponse.deserializeBinary
);


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.UsersResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.UsersResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.UserServiceClient.prototype.retrieveUsers =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.UserService/RetrieveUsers',
      request,
      metadata || {},
      methodDescriptor_UserService_RetrieveUsers,
      callback);
};


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.UsersResponse>}
 *     Promise that resolves to the response
 */
proto.pb.UserServicePromiseClient.prototype.retrieveUsers =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.UserService/RetrieveUsers',
      request,
      metadata || {},
      methodDescriptor_UserService_RetrieveUsers);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodDescriptor_UserService_UpdateUser = new grpc.web.MethodDescriptor(
  '/pb.UserService/UpdateUser',
  grpc.web.MethodType.UNARY,
  proto.pb.UserRequest,
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodInfo_UserService_UpdateUser = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.UserResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.UserResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.UserServiceClient.prototype.updateUser =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.UserService/UpdateUser',
      request,
      metadata || {},
      methodDescriptor_UserService_UpdateUser,
      callback);
};


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.UserResponse>}
 *     Promise that resolves to the response
 */
proto.pb.UserServicePromiseClient.prototype.updateUser =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.UserService/UpdateUser',
      request,
      metadata || {},
      methodDescriptor_UserService_UpdateUser);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodDescriptor_UserService_DeleteUser = new grpc.web.MethodDescriptor(
  '/pb.UserService/DeleteUser',
  grpc.web.MethodType.UNARY,
  proto.pb.UserRequest,
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.UserRequest,
 *   !proto.pb.UserResponse>}
 */
const methodInfo_UserService_DeleteUser = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.UserResponse,
  /**
   * @param {!proto.pb.UserRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.UserResponse.deserializeBinary
);


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.UserResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.UserResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.UserServiceClient.prototype.deleteUser =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.UserService/DeleteUser',
      request,
      metadata || {},
      methodDescriptor_UserService_DeleteUser,
      callback);
};


/**
 * @param {!proto.pb.UserRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.UserResponse>}
 *     Promise that resolves to the response
 */
proto.pb.UserServicePromiseClient.prototype.deleteUser =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.UserService/DeleteUser',
      request,
      metadata || {},
      methodDescriptor_UserService_DeleteUser);
};


module.exports = proto.pb;

