/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_project_pb = require('../proto/project_pb.js')
const proto = {};
proto.pb = require('./bench_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.BenchServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.BenchServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodDescriptor_BenchService_CreateBench = new grpc.web.MethodDescriptor(
  '/pb.BenchService/CreateBench',
  grpc.web.MethodType.UNARY,
  proto.pb.BenchRequest,
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodInfo_BenchService_CreateBench = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.BenchResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.BenchResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.BenchServiceClient.prototype.createBench =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.BenchService/CreateBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_CreateBench,
      callback);
};


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.BenchResponse>}
 *     Promise that resolves to the response
 */
proto.pb.BenchServicePromiseClient.prototype.createBench =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.BenchService/CreateBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_CreateBench);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodDescriptor_BenchService_RetrieveBench = new grpc.web.MethodDescriptor(
  '/pb.BenchService/RetrieveBench',
  grpc.web.MethodType.UNARY,
  proto.pb.BenchRequest,
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodInfo_BenchService_RetrieveBench = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.BenchResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.BenchResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.BenchServiceClient.prototype.retrieveBench =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.BenchService/RetrieveBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_RetrieveBench,
      callback);
};


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.BenchResponse>}
 *     Promise that resolves to the response
 */
proto.pb.BenchServicePromiseClient.prototype.retrieveBench =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.BenchService/RetrieveBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_RetrieveBench);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchesResponse>}
 */
const methodDescriptor_BenchService_RetrieveBenches = new grpc.web.MethodDescriptor(
  '/pb.BenchService/RetrieveBenches',
  grpc.web.MethodType.UNARY,
  proto.pb.BenchRequest,
  proto.pb.BenchesResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchesResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchesResponse>}
 */
const methodInfo_BenchService_RetrieveBenches = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.BenchesResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchesResponse.deserializeBinary
);


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.BenchesResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.BenchesResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.BenchServiceClient.prototype.retrieveBenches =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.BenchService/RetrieveBenches',
      request,
      metadata || {},
      methodDescriptor_BenchService_RetrieveBenches,
      callback);
};


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.BenchesResponse>}
 *     Promise that resolves to the response
 */
proto.pb.BenchServicePromiseClient.prototype.retrieveBenches =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.BenchService/RetrieveBenches',
      request,
      metadata || {},
      methodDescriptor_BenchService_RetrieveBenches);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodDescriptor_BenchService_UpdateBench = new grpc.web.MethodDescriptor(
  '/pb.BenchService/UpdateBench',
  grpc.web.MethodType.UNARY,
  proto.pb.BenchRequest,
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodInfo_BenchService_UpdateBench = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.BenchResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.BenchResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.BenchServiceClient.prototype.updateBench =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.BenchService/UpdateBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_UpdateBench,
      callback);
};


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.BenchResponse>}
 *     Promise that resolves to the response
 */
proto.pb.BenchServicePromiseClient.prototype.updateBench =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.BenchService/UpdateBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_UpdateBench);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodDescriptor_BenchService_DeleteBench = new grpc.web.MethodDescriptor(
  '/pb.BenchService/DeleteBench',
  grpc.web.MethodType.UNARY,
  proto.pb.BenchRequest,
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.BenchRequest,
 *   !proto.pb.BenchResponse>}
 */
const methodInfo_BenchService_DeleteBench = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.BenchResponse,
  /**
   * @param {!proto.pb.BenchRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.BenchResponse.deserializeBinary
);


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.BenchResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.BenchResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.BenchServiceClient.prototype.deleteBench =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.BenchService/DeleteBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_DeleteBench,
      callback);
};


/**
 * @param {!proto.pb.BenchRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.BenchResponse>}
 *     Promise that resolves to the response
 */
proto.pb.BenchServicePromiseClient.prototype.deleteBench =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.BenchService/DeleteBench',
      request,
      metadata || {},
      methodDescriptor_BenchService_DeleteBench);
};


module.exports = proto.pb;

