/**
 * @fileoverview gRPC-Web generated client stub for pb
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');


var proto_cell_pb = require('../proto/cell_pb.js')
const proto = {};
proto.pb = require('./stock_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.StockServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.pb.StockServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodDescriptor_StockService_CreateStock = new grpc.web.MethodDescriptor(
  '/pb.StockService/CreateStock',
  grpc.web.MethodType.UNARY,
  proto.pb.StockRequest,
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodInfo_StockService_CreateStock = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.StockResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.StockResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.StockServiceClient.prototype.createStock =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.StockService/CreateStock',
      request,
      metadata || {},
      methodDescriptor_StockService_CreateStock,
      callback);
};


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.StockResponse>}
 *     Promise that resolves to the response
 */
proto.pb.StockServicePromiseClient.prototype.createStock =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.StockService/CreateStock',
      request,
      metadata || {},
      methodDescriptor_StockService_CreateStock);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodDescriptor_StockService_RetrieveStock = new grpc.web.MethodDescriptor(
  '/pb.StockService/RetrieveStock',
  grpc.web.MethodType.UNARY,
  proto.pb.StockRequest,
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodInfo_StockService_RetrieveStock = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.StockResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.StockResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.StockServiceClient.prototype.retrieveStock =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.StockService/RetrieveStock',
      request,
      metadata || {},
      methodDescriptor_StockService_RetrieveStock,
      callback);
};


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.StockResponse>}
 *     Promise that resolves to the response
 */
proto.pb.StockServicePromiseClient.prototype.retrieveStock =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.StockService/RetrieveStock',
      request,
      metadata || {},
      methodDescriptor_StockService_RetrieveStock);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StocksResponse>}
 */
const methodDescriptor_StockService_RetrieveStocks = new grpc.web.MethodDescriptor(
  '/pb.StockService/RetrieveStocks',
  grpc.web.MethodType.UNARY,
  proto.pb.StockRequest,
  proto.pb.StocksResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StocksResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StocksResponse>}
 */
const methodInfo_StockService_RetrieveStocks = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.StocksResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StocksResponse.deserializeBinary
);


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.StocksResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.StocksResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.StockServiceClient.prototype.retrieveStocks =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.StockService/RetrieveStocks',
      request,
      metadata || {},
      methodDescriptor_StockService_RetrieveStocks,
      callback);
};


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.StocksResponse>}
 *     Promise that resolves to the response
 */
proto.pb.StockServicePromiseClient.prototype.retrieveStocks =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.StockService/RetrieveStocks',
      request,
      metadata || {},
      methodDescriptor_StockService_RetrieveStocks);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodDescriptor_StockService_UpdateStock = new grpc.web.MethodDescriptor(
  '/pb.StockService/UpdateStock',
  grpc.web.MethodType.UNARY,
  proto.pb.StockRequest,
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodInfo_StockService_UpdateStock = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.StockResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.StockResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.StockServiceClient.prototype.updateStock =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.StockService/UpdateStock',
      request,
      metadata || {},
      methodDescriptor_StockService_UpdateStock,
      callback);
};


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.StockResponse>}
 *     Promise that resolves to the response
 */
proto.pb.StockServicePromiseClient.prototype.updateStock =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.StockService/UpdateStock',
      request,
      metadata || {},
      methodDescriptor_StockService_UpdateStock);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodDescriptor_StockService_DeleteStock = new grpc.web.MethodDescriptor(
  '/pb.StockService/DeleteStock',
  grpc.web.MethodType.UNARY,
  proto.pb.StockRequest,
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.pb.StockRequest,
 *   !proto.pb.StockResponse>}
 */
const methodInfo_StockService_DeleteStock = new grpc.web.AbstractClientBase.MethodInfo(
  proto.pb.StockResponse,
  /**
   * @param {!proto.pb.StockRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.pb.StockResponse.deserializeBinary
);


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.pb.StockResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.pb.StockResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.pb.StockServiceClient.prototype.deleteStock =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/pb.StockService/DeleteStock',
      request,
      metadata || {},
      methodDescriptor_StockService_DeleteStock,
      callback);
};


/**
 * @param {!proto.pb.StockRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.pb.StockResponse>}
 *     Promise that resolves to the response
 */
proto.pb.StockServicePromiseClient.prototype.deleteStock =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/pb.StockService/DeleteStock',
      request,
      metadata || {},
      methodDescriptor_StockService_DeleteStock);
};


module.exports = proto.pb;

