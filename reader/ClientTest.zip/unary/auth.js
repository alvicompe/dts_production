import { PORT_SERVER, URL_SERVER } from '../../const/const'
import { AuthServiceClient } from '../pb/proto/auth_grpc_web_pb'
import { LoginRequest, User } from '../pb/proto/auth_pb'
// import { User } from '../pb/proto/user_pb'


const authService = new AuthServiceClient(`${URL_SERVER}:${PORT_SERVER}`,null, null)
const loginRequest = new LoginRequest()
const user = new User()

const AuthService = async method => {
  user.setUsername("dispatcher")
  user.setPassword("1234")
  loginRequest.setUser(user)
  switch (method) {
    case "auth":
      console.log("Login AuthService Starts...")
      return new Promise((resolve, reject) => {
        authService.login(loginRequest, null, (err, res) => {
          if (err) {
            console.log("error message", err.message)
            reject(err)
          } else {
            const auth = res.toObject()
            resolve(auth)
          }
        })
      })
    default:
      console.log("Case not found")
  }
}

export { AuthService }