import { PORT_SERVER, URL_SERVER } from "../../const/const";
import { ExcavatorServiceClient } from "../pb/proto/ExcavatorServiceClientPb";
import { Excavator, ExcavatorRequest } from "../pb/proto/excavator_pb";
const excavatorService = new ExcavatorServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
);

export const getExcavatorsAll = () => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };
  const excavator = new Excavator();
  const excavatorRequest = new ExcavatorRequest();
  excavatorRequest.setExcavator(excavator);
  return new Promise((resolve, reject) => {
    excavatorService.retrieveExcavators(
      excavatorRequest,
      metadata,
      (err, res) => {
        if (err) {
          console.log("error message excavators get", err.message);
          reject(err);
        } else {
          console.log("excavators", res);
          const resj = res.toObject();
          resolve(resj.excavatorsList ? resj.excavatorsList : []);
        }
      }
    );
  });
};
