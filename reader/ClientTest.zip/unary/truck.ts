import { PORT_SERVER, URL_SERVER } from "../../const/const"
import { ITruckInfo } from "../../dbo/interfaces/Unit"
import { TruckServiceClient } from "../pb/proto/TruckServiceClientPb"
import { Truck, TruckRequest } from "../pb/proto/truck_pb"
const truckService = new TruckServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
)
const truck = new Truck()
const truckRequest = new TruckRequest()
//console.log('urls',`${URL_SERVER}:${PORT_SERVER}`)
//const id = 'e198330b-5e8b-42ad-972c-049c376ba7a9'

export const getTrucksAll = () => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  }
  //truck.setId(id)
  truckRequest.setTruck(truck)
  return new Promise((resolve, reject) => {
    truckService.retrieveTrucks(truckRequest, metadata, (err, res) => {
      if (err) {
        console.log("error message trucks get", err.message)
        if (err.code === 500) {
          resolve([])
        } else reject(err)
      } else {
        //const trucks = res.getTrucksList()
        const resj: any = res.toObject().trucksList
        resolve(resj)
      }
    })
  })
}
