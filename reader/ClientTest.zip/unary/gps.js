import { URL_SERVER, PORT_SERVER } from '../../const/const'
import { GpsServiceClient } from '../pb/proto/gps_grpc_web_pb'
import { ServerGpsRequest } from '../pb/proto/gps_pb'
import { sleep } from '../tool/func'

const gpsService = new GpsServiceClient(`${URL_SERVER}:${PORT_SERVER}`,null, null)
const serverGpsRequest = new ServerGpsRequest()

const GpsService = (setGpsService) => {
  console.log('Streaming GpsService Starts...')
  const metadata = {'authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MjMyODg0MTIsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJkaXNwYXRjaGVyIn0.eQpkYMrA7L_CNyaZp78pNk_hd2GODefI8Dwc1-khCfY'}

  const stream = gpsService.serverStreamGps(serverGpsRequest, metadata)
  
  stream.on('data', res => {
    const obj = res.getGps().toObject()
    setGpsService(obj)
    //console.log('obj', JSON.stringify(obj))
  })

  stream.on('error', async err => {
    await sleep(3000)
    console.log('Streaming GpsService Error - Code:', err.code)
    console.log('Streaming GpsService Error - Message:', err.message)
    console.log("Trying to reconnect...")
    GpsService()
  })

  stream.on('end', () => {
    console.log('Streaming GpsService Ended!')
  })

  stream.on('status', status => {
    console.log('status', status)
  })

}

export { GpsService }