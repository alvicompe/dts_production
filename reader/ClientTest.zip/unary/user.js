import { PORT_SERVER, URL_SERVER } from '../../const/const'
import { UserServiceClient } from '../pb/proto/user_grpc_web_pb'
import { User, UserRequest } from '../pb/proto/user_pb'

const userService = new UserServiceClient(`${URL_SERVER}:${PORT_SERVER}`,null, null)
const user = new User()
const userRequest = new UserRequest()

const UserService = async method => {
  const metadata = {'authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MjMyODg0MTIsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJkaXNwYXRjaGVyIn0.eQpkYMrA7L_CNyaZp78pNk_hd2GODefI8Dwc1-khCfY'}

  // User fields to send
  // user.setId("test")
  user.setUsername("dispatcher")
  user.setRole("dispatcher")
  user.setPassword("1234")
  // User request fields to send
  userRequest.setUser(user)
  switch (method) {
    case "create":
      console.log("Create UserService Starts...")
      return new Promise((resolve, reject) => {
        userService.createUser(userRequest, metadata, (err, res) => {
          if (err) {
            console.log("error message", err.message)
            reject(err)
          } else {
            const user = res.getUser().toObject()
            resolve(user)
          }
        })
      })
    case "retrieve":
      console.log("Retrieve UserService Starts...")
      return new Promise((resolve, reject) => {
        userService.retrieveUser(userRequest, metadata, (err, res) => {
          if (err) {
            console.log("error message", err.message)
            reject(err)
          } else {
            const user = res.getUser().toObject()
            resolve(user)
          }
        })
      })
    case "update":
      console.log("Update UserService Starts...")
      return new Promise((resolve, reject) => {
        userService.updateUser(userRequest, metadata, (err, res) => {
          if (err) {
            console.log("error message", err.message)
            reject(err)
          } else {
            const user = res.getUser().toObject()
            resolve(user)
          }
        })
      })
    case "delete":
      console.log("Delete UserService Starts...")
      return new Promise((resolve, reject) => {
        userService.deleteUser(userRequest, metadata, (err, res) => {
          if (err) {
            console.log("error message", err.message)
            reject(err)
          } else {
            const user = res.getUser().toObject()
            resolve(user)
          }
        })
      })
    case "login":
      console.log("Login UserService Starts...")
      return new Promise((resolve, reject) => {
        userService.deleteUser(userRequest, metadata, (err, res) => {
          if (err) {
            console.log("error message", err.message)
            reject(err)
          } else {
            const user = res.getUser().toObject()
            resolve(user)
          }
        })
      })
    default:
      console.log("Case not found")
  }
}

export { UserService }