import { PORT_SERVER, URL_SERVER } from "../../const/const";
import { IRoute } from "../../dbo/interfaces/IRoute";
import { IExcavator, ITruck } from "../../dbo/interfaces/Unit";
import { OperationServiceClient } from "../pb/proto/OperationServiceClientPb";
import {
  Operation,
  OperationRequest,
  OperationReassigmentRequest,
} from "../pb/proto/operation_pb";
import { Upload, Download } from "../pb/proto/load_pb";
import { Polygon } from "../pb/proto/polygon_pb";
import { Cell } from "../pb/proto/cell_pb";
import { Dme } from "../pb/proto/dme_pb";
import { Pit } from "../pb/proto/pit_pb";
import { Pad } from "../pb/proto/pad_pb";
import { Project } from "../pb/proto/project_pb";
import { Road } from "../pb/proto/road_pb";
import { Truck } from "../pb/proto/truck_pb";
import { Stock } from "../pb/proto/stock_pb";
import { Excavator } from "../pb/proto/excavator_pb";
const operationService = new OperationServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
);

export const saveOperation = (
  polygon: any,
  cellUnload: any,
  trucks: Array<ITruck>,
  excavators: Array<IExcavator>,
  roads: Array<IRoute>
) => {
  console.log("unload", cellUnload);
  //return new Promise(()=>{});
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };
  const operation = new Operation();
  const upload = new Upload();
  const download = new Download();
  const poly = new Polygon();
  const cell = new Cell();
  const dme = new Dme();
  const stock = new Stock();
  const pit = new Pit();
  const project = new Project();
  const operationReq = new OperationRequest();

  console.log(polygon);
  if (polygon.type === 1) {
    poly.setId(polygon.value.id);
    upload.setType(1);
    project.addPolygon(poly);
    project.setId(polygon.idProject);
    pit.addProject(project);
    upload.setPit(pit);
  } else {
    //falta
    stock.setId(polygon.value.id);
    upload.setType(3);
    upload.setStock(stock);
  }

  if (cellUnload.type === 1) {
    const pad = new Pad();
    pad.setId(cellUnload.value.idPad);
    cell.setId(cellUnload.value.id);
    pad.addCell(cell);
    download.setType(2);
    download.setPad(pad);
  }
  if (cellUnload.type === 2) {
    dme.setId(cellUnload.value.idDme);
    cell.setId(cellUnload.value.id);
    dme.addCell(cell);
    download.setType(4);
    download.setDme(dme);
  }

  operation.setShift(1); //Turno
  operation.setState(2); //estado
  operation.setUpload(upload);
  operation.setDownload(download);

  roads.forEach((r) => {
    const road = new Road();
    road.setId(r.id);
    operation.addRoad(road);
  });

  trucks.forEach((r) => {
    const truck = new Truck();
    truck.setId(r.id);
    operation.addTruck(truck);
  });
  excavators.forEach((r) => {
    const excavator = new Excavator();
    excavator.setId(r.id);
    operation.addExcavator(excavator);
  });
  console.log("operation", operation);
  operationReq.setOperation(operation);
  return new Promise((resolve, reject) => {
    operationService.createOperation(
      operationReq,
      metadata,
      (err: any, res: any) => {
        if (err) {
          console.log("error message", err.message);
          reject(err);
        } else {
          const operation = res.getOperation().toObject();
          console.log("saveOperationResponse", operation);
          resolve(operation);
        }
      }
    );
  });
};

export const getOperationActivesList = () => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };
  const operation = new Operation();
  const operationRequest = new OperationRequest();
  operationRequest.setOperation(operation);
  return new Promise((resolve, reject) => {
    operationService.retrieveOperations(
      operationRequest,
      metadata,
      (err: any, res: any) => {
        if (err) {
          console.log("error message operations get", err.message);
          reject(err);
        } else {
          const resj = res.toObject();
          console.log("operations", res);
          resolve(resj.operationsList ? resj.operationsList : []);
        }
      }
    );
  });
};

export const reassigmentTrucks = (idDest: string, trucks: Array<ITruck>) => {
  console.log("RESSIGMENT_DATA_SEND: ", idDest, trucks);
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };
  const operation = new Operation();
  const opeReass = new OperationReassigmentRequest();

  operation.setId(idDest);
  opeReass.setOperationDestination(operation);
  console.log("idDest", idDest);
  console.log("trucks", trucks);

  /*   opeReass.setIdOperationFrom(idFrom);
   */
  trucks.map((t) => {
    const truck = new Truck();
    truck.setId(t.id);
    truck.setDeviceId(t.deviceId);
    truck.setDeviceAlias(t.deviceAlias);
    truck.setDeviceInterval(t.deviceInterval);
    truck.setDescription(t.description!);
    truck.setPlate(t.plate);
    opeReass.addTruck(truck);
  });
  return new Promise((resolve, reject) => {
    operationService.reassigmentTrucksOperation(
      opeReass,
      metadata,
      (err: any, res: any) => {
        if (err) {
          console.log("error message operations get", err.message);
          reject(err);
        } else {
          const resj = res.toObject();
          console.log("operationsbackend", resj);
          resolve(resj);
        }
      }
    );
  });
};

export const finalizeOperation = (idOperationFinalize: any) => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };

  /*   const idOperationFinalize = "12c5ba97-a889-413a-8a15-0cd7a1df9414";
   */ const operation = new Operation();
  const opeFinalize = new OperationRequest();

  operation.setId(idOperationFinalize);
  opeFinalize.setOperation(operation);

  return new Promise((resolve, reject) => {
    operationService.finalizeOperation(
      opeFinalize,
      metadata,
      (err: any, res: any) => {
        if (err) {
          console.log("error message operations get", err.message);
          reject(err);
        } else {
          const resj = res.toObject();
          console.log("operationFinalize", resj);
          resolve(resj);
        }
      }
    );
  });
};

export const removeTrucks = (trucks: Array<ITruck>, idFrom: string) => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };

  const operation = new Operation();
  const operationRequest = new OperationRequest();
  operation.setId(idFrom);

  trucks.map((t) => {
    const truck = new Truck();
    truck.setId(t.id);
    truck.setDeviceId(t.deviceId);
    truck.setDeviceAlias(t.deviceAlias);
    truck.setDeviceInterval(t.deviceInterval);
    truck.setDescription(t.description!);
    truck.setPlate(t.plate);
    operation.addTruck(truck);
  });

  operationRequest.setOperation(operation);

  return new Promise((resolve, reject) => {
    operationService.removeTrucksOperation(
      operationRequest,
      metadata,
      (err: any, res: any) => {
        if (err) {
          console.log("error message operations get", err.message);
          reject(err);
        } else {
          const resj = res.toObject();
          console.log("removeTrucks", resj);
          resolve(resj);
        }
      }
    );
  });
};
