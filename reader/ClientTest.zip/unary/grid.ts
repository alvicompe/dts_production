import { PORT_SERVER, URL_SERVER } from "../../const/const";
import { GridServiceClient } from "../pb/proto/GridServiceClientPb";
import { GridRequest } from "../pb/proto/grid_pb";
const gridService = new GridServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
);

export const generateGrid = (setLoad: Function, setErrorGrid: Function) => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };
  const gridRequest = new GridRequest();
  gridRequest.setRead(true);
  setLoad(true);
  return new Promise((resolve, reject) => {
    gridService.createGrid(gridRequest, metadata, (err, res) => {
      setLoad(false);
      if (err !== null) {
        console.log("err", err);
        setErrorGrid(err.message);
      } else {
        console.log("createGrid", res);
        console.log(res.getDone());
        if (res.getDone()) {
          setErrorGrid("");
        } else {
          setErrorGrid("Error al Generar Grids");
        }
      }
    });
  });
};
