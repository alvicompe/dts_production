import { PORT_SERVER, URL_SERVER } from "../../const/const";
import { ITruck } from "../../dbo/interfaces/Unit";
import { ReportServiceClient } from "../pb/proto/ReportServiceClientPb";
import { timestampHelper } from "../tool/Timestamp";

import { ReportRequest, DownloadRequest } from "../pb/proto/report_pb";
import { Truck } from "../pb/proto/truck_pb";
const reportService = new ReportServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
);

export const truckcyclesReport = (
  dateStart: string,
  dateEnd: string,
  shift: number
) => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };
  const reportRequest = new ReportRequest();
  console.log(dateStart);
  console.log(dateEnd);

  reportRequest.setDateStart(timestampHelper(dateStart));
  reportRequest.setDateEnd(timestampHelper(dateEnd));
  reportRequest.setShift(shift);

  return new Promise((resolve, reject) => {
    reportService.retrieveReport(reportRequest, metadata, (err, res) => {
      console.log(err);
      console.log(res);

      if (err) {
        console.log("error message reportCycles get", err.message);
        if (err.code === 500) {
          resolve([]);
        } else reject(err);
      } else {
        const resj = res.toObject();
        console.log("resj", resj);
        resolve(resj ? resj : []);
      }
    });
  });
};

export const dowloadFile = (
  dateStart: string,
  dateEnd: string,
  shift: number,
  trunks: Array<ITruck>,
  allTrucks: boolean
) => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  };
  const reportDonwloadRequest = new DownloadRequest();

  reportDonwloadRequest.setDateStart(timestampHelper(dateStart));
  reportDonwloadRequest.setDateEnd(timestampHelper(dateEnd));
  reportDonwloadRequest.setShift(shift);
  reportDonwloadRequest.setAllTruck(allTrucks);
  console.log(allTrucks);
  trunks.forEach((t: ITruck) => {
    const truck = new Truck();
    truck.setId(t.id);
    truck.setDeviceId(t.deviceId);
    console.log("t.deviceId", truck);

    reportDonwloadRequest.addTruck(truck);
  });
  /*   reportDonwloadRequest.addTruck(trunks);
   */
  return new Promise((resolve, reject) => {
    console.log("resolve", resolve);
    console.log("reject", reject);
    reportService.downloadReport(
      reportDonwloadRequest,
      metadata,
      (err, res) => {
        console.log("reportDonwloadRequest", reportDonwloadRequest);

        if (err) {
          console.log("error message excavators get", err.message);
          reject(err);
        } else {
          console.log("res", res.getFile());
          var byteArray = new Uint8Array(res.getFile() as Uint8Array);
          var a = window.document.createElement("a");
          a.href = window.URL.createObjectURL(
            new Blob([byteArray], { type: "application/octet-stream" })
          );

          // supply your own fileName here...
          a.download = res.getFileName();
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          const resj = res.toObject();
          console.log("reports", resj);
          resolve(resj);
        }
      }
    );
  });
};
