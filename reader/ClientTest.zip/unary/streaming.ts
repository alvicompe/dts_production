import { ClientReadableStream } from "grpc-web"
import { useEffect } from "react"
import { URL_SERVER, PORT_SERVER } from "../../const/const"
import { ITruckInfo } from "../../dbo/interfaces/Unit"
import { useAppDispatch, useAppSelector } from "../../hooks/hooksReducer"
import {
  newStateTruck,
  setList as setTruckList,
} from "../../reducers/units/TruckReducer"
import {
  newStateExcavator,
  setList as setListExcavator,
} from "../../reducers/units/ExcavatorReducer"
import {
  selectExcavatorList,
  startExvatorInfoList,
} from "../../reducers/units/ExcavatorReducer"
import {
  selectTruckList,
  startTruckInfoList,
} from "../../reducers/units/TruckReducer"
import {
  TruckInfoServiceClient,
  ExcavatorInfoServiceClient,
} from "../pb/proto/StreamingServiceClientPb"
import {
  TruckInfoRequest,
  ExcavatorInfoRequest,
} from "../pb/proto/streaming_pb"
import { StateTruckStreamReducer } from "../../dbo/interfaces/streaming/StreamTruck"

const truckInfoService = new TruckInfoServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
)
const excavatorInfoService = new ExcavatorInfoServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
)

const truckInfoRequest = new TruckInfoRequest()
const excavatorInfoRequest = new ExcavatorInfoRequest()
const metadata = {
  authorization:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MjY1MDA1MjksInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJBRE0ifQ.keSI9KQD51TBTVqyQRq6HDdt9Pc1maJ4bC_EYdiSgTY",
}
export const TruckInfoStream = () => {
  const dispatch = useAppDispatch()
  const { truckInfoList, initial } = useAppSelector(selectTruckList)

  useEffect(() => {
    dispatch(startTruckInfoList())
  }, [])
  useEffect(() => {
    let stream: ClientReadableStream<unknown>
    if (initial === StateTruckStreamReducer.INITIAL) {
      console.log("Streaming InfoService Starts...")
      dispatch(setTruckList(truckInfoList)) //Init list
      stream = truckInfoService.serverStream(truckInfoRequest, metadata)

      stream.on("data", (res: any) => {
        const obj: ITruckInfo = res.getInfo().toObject()
        /*         console.log("res cv", obj)
         */ dispatch(newStateTruck(obj))
      })

      stream.on("error", async (err) => {
        //await sleep(3000)
        console.log("Streaming TruckInfoService Error - Code:", err.code)
        console.log("Streaming TruckInfoService Error - Message:", err.message)
        console.log("Trying to reconnect to TruckInfoService...")
        //GpsService()
      })

      stream.on("end", () => {
        console.log("Streaming TruckInfoService Ended!")
      })
    }

    return () => {
      // if (stream) stream.cancel()
    }
  }, [initial])
  return null
}

export const ExcavatorInfoStream = () => {
  const dispatch = useAppDispatch()

  const { excavatorInfoList, initial } = useAppSelector(selectExcavatorList)
  useEffect(() => {
    dispatch(startExvatorInfoList())
  }, [])
  useEffect(() => {
    let stream: ClientReadableStream<unknown>
    if (initial === StateTruckStreamReducer.INITIAL) {
      dispatch(setListExcavator(excavatorInfoList)) //Init list
      console.log("Streaming ExcavatorInfoService Starts...")
      const stream = excavatorInfoService.serverStream(
        excavatorInfoRequest,
        metadata
      )

      stream.on("data", (res: any) => {
        const obj = res.getInfo().toObject()
        //setData(obj)
        /*         console.log("res ex", obj)
         */ dispatch(newStateExcavator(obj))
      })

      stream.on("error", async (err) => {
        // await sleep(3000)
        console.log("Streaming ExcavatorInfoService Error - Code:", err.code)
        console.log(
          "Streaming ExcavatorInfoService Error - Message:",
          err.message
        )
        console.log("Trying to reconnect to ExcavatorInfoService...")
        // GpsService()
      })

      stream.on("end", () => {
        console.log("Streaming ExcavatorInfoService Ended!")
      })
    }
    return () => {
      if (stream) stream.cancel()
    }
  }, [initial])

  // stream.on('status', status => {
  //   console.log('status', status)
  // })
  return null
}
