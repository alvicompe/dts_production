import { PORT_SERVER, URL_SERVER } from "../../const/const"
import { GeoServiceClient } from "../pb/proto/GeoServiceClientPb"
import { Geo, GeoRequest, GeoResponse } from "../pb/proto/geo_pb"

const geoService = new GeoServiceClient(
  `${URL_SERVER}:${PORT_SERVER}`,
  null,
  null
)
const geoRequest = new GeoRequest()

const GeoService = async () => {
  const metadata = {
    authorization:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MzQzODk4MDUsInVzZXJuYW1lIjoiZGlzcGF0Y2hlciIsInJvbGUiOiJESVMifQ.IIKVGiv1ve4AST9EdQ1XjujDWDG3qCHzF57knK7A1Y8",
  }
  return new Promise((resolve, reject) => {
    geoService.retrieveGeo(geoRequest, metadata, (err, res: GeoResponse) => {
      if (err) {
        console.log(
          "error message al solicitar data de poligonos y otras feactures",
          err.message
        )
        reject(err)
      } else {
        const geo = res.getGeo()?.toObject()
        resolve(geo)
      }
    })
  })
}

export { GeoService }
